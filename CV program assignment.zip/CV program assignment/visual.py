import math
import threading
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import mediapipe as mp


BaseOptions = mp.tasks.BaseOptions
FaceLandmarker = mp.tasks.vision.FaceLandmarker
FaceLandmarkerOptions = mp.tasks.vision.FaceLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode


MODEL_PATH = Path(__file__).resolve().parent / "face_landmarker.task"

# 下面这些索引来自 MediaPipe Face Mesh 的标准关键点编号。
# 本项目不会直接使用全部关键点，而是只抽取和头姿、眼睛开合最相关的那几组。
LEFT_EYE_CLUSTER_INDICES = [33, 133, 160, 159, 158, 157, 173, 144, 145, 153]
RIGHT_EYE_CLUSTER_INDICES = [362, 263, 385, 386, 387, 388, 398, 373, 374, 380]
NOSE_CLUSTER_INDICES = [1, 4, 5, 195, 197]
MOUTH_CLUSTER_INDICES = [13, 14, 0, 17, 78, 308]
# 下面两组点专门用于判断“嘴巴是不是张开到足够大”。
# 13 / 14 是上下唇中部，最适合拿来量“嘴巴竖向张开量”；
# 78 / 308 是嘴角两端，最适合拿来量“当前嘴宽”，用来做尺度归一化。
MOUTH_OPEN_VERTICAL_INDICES = (13, 14)
MOUTH_OPEN_HORIZONTAL_INDICES = (78, 308)

# EAR 只需要 6 个眼部关键点即可完成计算，因此单独准备更精简的索引。
LEFT_EAR_INDICES = [33, 160, 158, 133, 153, 144]
RIGHT_EAR_INDICES = [362, 385, 387, 263, 373, 380]


@dataclass
class FaceAnalysis:
    """单帧人脸分析结果。"""

    # yaw / pitch 是扣除了中心姿态后的相对控制量，主流程真正用它们驱动鼠标。
    yaw: float
    pitch: float
    # raw_yaw / raw_pitch 是由关键点直接计算出的原始姿态值，尚未扣掉中心偏置。
    raw_yaw: float
    raw_pitch: float
    # center_yaw / center_pitch 表示当前系统认为的“自然正视中心”姿态。
    center_yaw: float
    center_pitch: float
    # calibrated 与 calibration_* 用来表示启动阶段自动校准是否完成以及完成进度。
    calibrated: bool
    calibration_progress: int
    calibration_target: int
    # 以下坐标主要供调试绘图和后续几何计算复用。
    left_eye_center: Tuple[int, int]
    right_eye_center: Tuple[int, int]
    nose_tip: Tuple[int, int]
    mouth_center: Tuple[int, int]
    eye_midpoint: Tuple[int, int]
    # EAR 越小越接近闭眼。
    left_eye_ear: float
    right_eye_ear: float
    # 左右眼最终稳定后的开闭状态。
    left_eye_closed: bool
    right_eye_closed: bool
    # mouth_open_ratio:
    #     当前帧的“张嘴比例”，这里定义为“上下唇距离 / 嘴角宽度”。
    #     它比直接用像素距离更稳，因为会自动抵消脸离镜头远近变化带来的整体缩放。
    mouth_open_ratio: float
    # mouth_open:
    #     经过滞回阈值和连续多帧确认后的稳定张嘴状态。
    #     主流程不会拿原始比例直接切模式，而是优先使用这个更稳的布尔状态。
    mouth_open: bool
    # debug_groups 保存分组后的关键点，便于统一绘制调试层。
    debug_groups: Dict[str, List[Tuple[int, int]]]


class FaceResultBuffer:
    """保存 MediaPipe 异步返回的最新结果。"""

    # 异步回调线程和主循环线程都会访问结果缓存，所以需要锁来保护。
    def __init__(self):
        self._lock = threading.Lock()
        self._latest_result = None

    # 每次有新的检测结果就覆盖旧结果，主流程只关心“最近一次可用结果”。
    def save_result(self, result, _output_image, _timestamp_ms):
        with self._lock:
            self._latest_result = result

    # 主循环从这里安全地读取最近一次检测结果。
    def get_latest_result(self):
        with self._lock:
            return self._latest_result


def create_face_landmarker(result_callback):
    # result_callback 是 MediaPipe 在异步模式下返回结果时调用的回调函数。
    """创建 MediaPipe Face Landmarker。"""
    options = FaceLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=str(MODEL_PATH)),
        running_mode=VisionRunningMode.LIVE_STREAM,
        num_faces=1,
        min_face_detection_confidence=0.6,
        min_face_presence_confidence=0.6,
        min_tracking_confidence=0.6,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=False,
        result_callback=result_callback,
    )
    return FaceLandmarker.create_from_options(options)


def make_mp_image(frame_bgr):
    # OpenCV 使用 BGR，MediaPipe 需要 RGB，这里专门做格式转换。
    """把 OpenCV 的 BGR 图像转换成 MediaPipe Image。"""
    frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    return mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_rgb)


def _to_pixel(face_landmarks, index: int, frame_w: int, frame_h: int) -> Tuple[int, int]:
    # MediaPipe landmark 的 x/y 是归一化坐标，这里换算成当前帧像素坐标。
    landmark = face_landmarks[index]
    return int(landmark.x * frame_w), int(landmark.y * frame_h)


def _collect_pixels(face_landmarks, indices: List[int], frame_w: int, frame_h: int) -> List[Tuple[int, int]]:
    # 按索引批量取点，减少 analyze 里重复样板代码。
    return [_to_pixel(face_landmarks, index, frame_w, frame_h) for index in indices]


def _average_points(points: List[Tuple[int, int]]) -> Tuple[int, int]:
    # 对点簇求几何中心，常用于把一组点压缩成一个代表位置。
    if not points:
        return 0, 0

    sum_x = sum(point[0] for point in points)
    sum_y = sum(point[1] for point in points)
    return int(round(sum_x / len(points))), int(round(sum_y / len(points)))


def _distance(point_a: Tuple[int, int], point_b: Tuple[int, int]) -> float:
    # 统一欧氏距离计算，供眼距、面部高度和 EAR 复用。
    return math.hypot(point_a[0] - point_b[0], point_a[1] - point_b[1])


def _midpoint(point_a: Tuple[int, int], point_b: Tuple[int, int]) -> Tuple[int, int]:
    # 这里主要用来得到左右眼中心之间的中点。
    return int(round((point_a[0] + point_b[0]) / 2.0)), int(round((point_a[1] + point_b[1]) / 2.0))


def _eye_aspect_ratio(points: List[Tuple[int, int]]) -> float:
    # EAR = (两条竖向眼睑距离之和) / (2 * 横向眼宽)。
    # 眼睛闭上时竖向距离会显著缩小，因此 EAR 会下降。
    if len(points) != 6:
        return 0.0

    p1, p2, p3, p4, p5, p6 = points
    vertical_1 = _distance(p2, p6)
    vertical_2 = _distance(p3, p5)
    horizontal = max(_distance(p1, p4), 1e-6)
    return (vertical_1 + vertical_2) / (2.0 * horizontal)


class FaceAnalyzer:
    """
    把 MediaPipe 关键点转换成项目真正需要的控制信号。

    输出内容主要包括：
    - 头部姿态 `yaw / pitch`
    - 左右眼 EAR 和闭眼状态
    - 自动中心校准进度
    - 调试绘图需要的关键点分组
    """

    def __init__(
        self,
        eye_closed_threshold: float = 0.18,
        eye_reopen_threshold: float = 0.21,
        eye_state_confirm_frames: int = 3,
        calibration_frames: int = 30,
        center_drift_alpha: float = 0.02,
        center_drift_limit: float = 0.05,
        mouth_open_threshold: float = 0.16,
        mouth_close_threshold: float = 0.12,
        mouth_state_confirm_frames: int = 3,
    ):
        # eye_closed_threshold:
        #     EAR 低于该值时，开始朝“闭眼”方向判断。
        # eye_reopen_threshold:
        #     EAR 高于该值时，开始朝“睁眼”方向判断。
        #     它通常高于 closed_threshold，用于形成滞回。
        # eye_state_confirm_frames:
        #     同一判断需要连续满足多少帧才正式切换状态。
        # calibration_frames:
        #     启动初期估计中心姿态时，最多保留多少帧样本。
        # center_drift_alpha:
        #     已完成校准后，中心姿态缓慢跟随长期习惯变化的更新比例。
        # center_drift_limit:
        #     只有当前姿态已经足够接近中心时，才允许做慢漂移修正。
        # mouth_open_threshold:
        #     嘴巴从“闭合状态”切到“张开状态”时使用的上阈值。
        #     只有张嘴比例明显超过它，才会开始判定为“张嘴手势”。
        # mouth_close_threshold:
        #     嘴巴从“张开状态”回到“闭合状态”时使用的下阈值。
        #     它要低于 open_threshold，这样就能形成滞回区，减少嘴唇边缘抖动带来的来回跳变。
        # mouth_state_confirm_frames:
        #     张嘴或闭嘴都必须连续满足这么多帧，才正式切换口部状态。
        #     这样可以把说话时的一些很短的口型变化过滤掉一部分。
        self.eye_closed_threshold = eye_closed_threshold
        self.eye_reopen_threshold = max(eye_reopen_threshold, eye_closed_threshold + 0.01)
        self.eye_state_confirm_frames = max(1, eye_state_confirm_frames)
        self.calibration_frames = calibration_frames
        self.center_drift_alpha = center_drift_alpha
        self.center_drift_limit = center_drift_limit
        self.mouth_open_threshold = mouth_open_threshold
        self.mouth_close_threshold = max(0.0, min(mouth_close_threshold, mouth_open_threshold - 0.01))
        self.mouth_state_confirm_frames = max(1, mouth_state_confirm_frames)

        # _yaw_samples / _pitch_samples 保存启动阶段用于估计中心姿态的样本窗口。
        self._yaw_samples = deque(maxlen=calibration_frames)
        self._pitch_samples = deque(maxlen=calibration_frames)

        # center_* 是当前维护中的中心姿态，calibrated 表示是否完成首次自动估计。
        self.center_yaw = 0.0
        self.center_pitch = 0.0
        self.calibrated = False

        # 下面这些状态用于把原始 EAR 序列稳定成“开 / 闭”的布尔结果。
        self.left_eye_closed_state = False
        self.right_eye_closed_state = False
        self.left_eye_closed_frames = 0
        self.right_eye_closed_frames = 0
        self.left_eye_open_frames = 0
        self.right_eye_open_frames = 0

        # 口部状态机和眼睛状态机的思路完全一致：
        # 不直接相信某一帧的张嘴比例，而是要求连续多帧满足条件，才真正切换状态。
        self.mouth_open_state = False
        self.mouth_open_frames = 0
        self.mouth_close_frames = 0

    # 输入一个新的 EAR 值，并结合历史计数把它稳定成最终的闭眼状态。
    def _smooth_eye_state(
        self,
        ear_value: float,
        current_closed: bool,
        closed_frames: int,
        open_frames: int,
    ) -> Tuple[bool, int, int]:
        """用滞回和连续帧确认来稳定眼睛开闭状态。"""
        if current_closed:
            if ear_value > self.eye_reopen_threshold:
                open_frames += 1
                closed_frames = 0
                if open_frames >= self.eye_state_confirm_frames:
                    current_closed = False
                    open_frames = 0
            else:
                open_frames = 0
                closed_frames = 0
        else:
            if ear_value < self.eye_closed_threshold:
                closed_frames += 1
                open_frames = 0
                if closed_frames >= self.eye_state_confirm_frames:
                    current_closed = True
                    closed_frames = 0
            else:
                closed_frames = 0
                open_frames = 0

        return current_closed, closed_frames, open_frames

    def _smooth_mouth_state(
        self,
        mouth_open_ratio: float,
        current_open: bool,
        open_frames: int,
        close_frames: int,
    ) -> Tuple[bool, int, int]:
        """
        用滞回阈值和连续多帧确认，稳定“嘴巴是否张开”的判定。

        这里之所以不直接做 `mouth_open_ratio > threshold`，是因为嘴唇关键点会有抖动，
        而且人说话时嘴型会快速变化。如果没有这层稳定器，滚轮模式会非常容易误触。
        """
        if current_open:
            if mouth_open_ratio < self.mouth_close_threshold:
                close_frames += 1
                open_frames = 0
                if close_frames >= self.mouth_state_confirm_frames:
                    current_open = False
                    close_frames = 0
            else:
                open_frames = 0
                close_frames = 0
        else:
            if mouth_open_ratio > self.mouth_open_threshold:
                open_frames += 1
                close_frames = 0
                if open_frames >= self.mouth_state_confirm_frames:
                    current_open = True
                    open_frames = 0
            else:
                open_frames = 0
                close_frames = 0

        return current_open, open_frames, close_frames

    # 把 focus 校准模块输出的新中心姿态直接应用到视觉分析器。
    def apply_focus_center(self, center_yaw: float, center_pitch: float):
        """应用注视校准后得到的新中心姿态。"""
        self.center_yaw = center_yaw
        self.center_pitch = center_pitch
        self.calibrated = True
        self._yaw_samples.clear()
        self._pitch_samples.clear()

    # 中心姿态维护分两段：
    # 1. 启动初期采样若干帧自然姿态，得到初始中心
    # 2. 运行期仅在姿态已经靠近中心时，做很慢的漂移修正
    def _update_center(self, raw_yaw: float, raw_pitch: float, left_eye_closed: bool, right_eye_closed: bool):
        """
        维护中心姿态。

        启动初期会根据若干帧自然姿态做一次自动估计；
        完成后只在当前姿态已经很接近中心时，才允许中心值慢速漂移修正。
        """
        if left_eye_closed or right_eye_closed:
            return

        if not self.calibrated:
            self._yaw_samples.append(raw_yaw)
            self._pitch_samples.append(raw_pitch)

            self.center_yaw = sum(self._yaw_samples) / len(self._yaw_samples)
            self.center_pitch = sum(self._pitch_samples) / len(self._pitch_samples)

            if len(self._yaw_samples) >= self.calibration_frames:
                self.calibrated = True
            return

        if (
            abs(raw_yaw - self.center_yaw) < self.center_drift_limit
            and abs(raw_pitch - self.center_pitch) < self.center_drift_limit
        ):
            self.center_yaw = self.center_yaw * (1.0 - self.center_drift_alpha) + raw_yaw * self.center_drift_alpha
            self.center_pitch = self.center_pitch * (1.0 - self.center_drift_alpha) + raw_pitch * self.center_drift_alpha

    # analyze 是视觉模块的主入口：
    # 输入单帧关键点，输出主流程需要的姿态、眼部状态和调试信息。
    def analyze(self, face_landmarks, frame_w: int, frame_h: int) -> FaceAnalysis:
        """分析单帧人脸关键点。"""
        # 先把关键点批量转成像素坐标，后面的几何计算都基于像素空间完成。
        left_eye_points = _collect_pixels(face_landmarks, LEFT_EYE_CLUSTER_INDICES, frame_w, frame_h)
        right_eye_points = _collect_pixels(face_landmarks, RIGHT_EYE_CLUSTER_INDICES, frame_w, frame_h)
        nose_points = _collect_pixels(face_landmarks, NOSE_CLUSTER_INDICES, frame_w, frame_h)
        mouth_points = _collect_pixels(face_landmarks, MOUTH_CLUSTER_INDICES, frame_w, frame_h)
        upper_lip_point = _to_pixel(face_landmarks, MOUTH_OPEN_VERTICAL_INDICES[0], frame_w, frame_h)
        lower_lip_point = _to_pixel(face_landmarks, MOUTH_OPEN_VERTICAL_INDICES[1], frame_w, frame_h)
        mouth_left_corner = _to_pixel(face_landmarks, MOUTH_OPEN_HORIZONTAL_INDICES[0], frame_w, frame_h)
        mouth_right_corner = _to_pixel(face_landmarks, MOUTH_OPEN_HORIZONTAL_INDICES[1], frame_w, frame_h)

        left_ear_points = _collect_pixels(face_landmarks, LEFT_EAR_INDICES, frame_w, frame_h)
        right_ear_points = _collect_pixels(face_landmarks, RIGHT_EAR_INDICES, frame_w, frame_h)

        # 把点簇压缩成代表中心点，便于计算眼距、双眼中点和面部几何关系。
        left_eye_center = _average_points(left_eye_points)
        right_eye_center = _average_points(right_eye_points)
        nose_tip = _average_points(nose_points)
        mouth_center = _average_points(mouth_points)
        eye_midpoint = _midpoint(left_eye_center, right_eye_center)

        # eye_distance 和 face_height 分别负责给 yaw / pitch 做尺度归一化，
        # 避免人脸离镜头远近变化时姿态数值量级跟着大幅改变。
        eye_distance = max(_distance(left_eye_center, right_eye_center), 1.0)
        face_height = max(_distance(eye_midpoint, mouth_center), 1.0)

        # 鼻尖相对双眼中点的位置，能粗略反映左右转头和抬头低头。
        raw_yaw = (nose_tip[0] - eye_midpoint[0]) / eye_distance
        raw_pitch = (nose_tip[1] - eye_midpoint[1]) / face_height

        # 张嘴比例定义为“上下唇间距 / 嘴角宽度”。
        # 用比例而不是像素值，能减少人脸远近变化带来的影响。
        mouth_open_distance = _distance(upper_lip_point, lower_lip_point)
        mouth_width = max(_distance(mouth_left_corner, mouth_right_corner), 1.0)
        mouth_open_ratio = mouth_open_distance / mouth_width

        # EAR 越小说明上下眼睑越靠近，更接近闭眼状态。
        left_eye_ear = _eye_aspect_ratio(left_ear_points)
        right_eye_ear = _eye_aspect_ratio(right_ear_points)

        (
            self.left_eye_closed_state,
            self.left_eye_closed_frames,
            self.left_eye_open_frames,
        ) = self._smooth_eye_state(
            left_eye_ear,
            self.left_eye_closed_state,
            self.left_eye_closed_frames,
            self.left_eye_open_frames,
        )
        (
            self.right_eye_closed_state,
            self.right_eye_closed_frames,
            self.right_eye_open_frames,
        ) = self._smooth_eye_state(
            right_eye_ear,
            self.right_eye_closed_state,
            self.right_eye_closed_frames,
            self.right_eye_open_frames,
        )

        left_eye_closed = self.left_eye_closed_state
        right_eye_closed = self.right_eye_closed_state

        (
            self.mouth_open_state,
            self.mouth_open_frames,
            self.mouth_close_frames,
        ) = self._smooth_mouth_state(
            mouth_open_ratio,
            self.mouth_open_state,
            self.mouth_open_frames,
            self.mouth_close_frames,
        )

        # 先维护中心姿态，再把原始姿态换算成围绕中心的相对姿态。
        self._update_center(raw_yaw, raw_pitch, left_eye_closed, right_eye_closed)

        yaw = raw_yaw - self.center_yaw
        pitch = raw_pitch - self.center_pitch

        return FaceAnalysis(
            yaw=yaw,
            pitch=pitch,
            raw_yaw=raw_yaw,
            raw_pitch=raw_pitch,
            center_yaw=self.center_yaw,
            center_pitch=self.center_pitch,
            calibrated=self.calibrated,
            calibration_progress=len(self._yaw_samples),
            calibration_target=self.calibration_frames,
            left_eye_center=left_eye_center,
            right_eye_center=right_eye_center,
            nose_tip=nose_tip,
            mouth_center=mouth_center,
            eye_midpoint=eye_midpoint,
            left_eye_ear=left_eye_ear,
            right_eye_ear=right_eye_ear,
            left_eye_closed=left_eye_closed,
            right_eye_closed=right_eye_closed,
            mouth_open_ratio=mouth_open_ratio,
            mouth_open=self.mouth_open_state,
            debug_groups={
                "left_eye": left_eye_points,
                "right_eye": right_eye_points,
                "nose": nose_points,
                "mouth": mouth_points,
            },
        )


def draw_debug_info(frame, analysis: FaceAnalysis, gesture_text: Optional[str] = None):
    # 这个函数只负责调试可视化，不参与控制算法本身。
    """在画面上绘制姿态、EAR 和关键点调试信息。"""
    # 不同特征分组用不同颜色，便于快速确认关键点是否落在正确位置。
    colors = {
        "left_eye": (255, 120, 0),
        "right_eye": (0, 180, 255),
        "nose": (0, 255, 0),
        "mouth": (255, 0, 255),
    }

    for group_name, points in analysis.debug_groups.items():
        color = colors[group_name]
        for point in points:
            cv2.circle(frame, point, 2, color, -1)

    cv2.circle(frame, analysis.left_eye_center, 4, (255, 120, 0), -1)
    cv2.circle(frame, analysis.right_eye_center, 4, (0, 180, 255), -1)
    cv2.circle(frame, analysis.nose_tip, 5, (0, 255, 0), -1)
    cv2.circle(frame, analysis.mouth_center, 4, (255, 0, 255), -1)
    cv2.circle(frame, analysis.eye_midpoint, 4, (0, 255, 255), -1)

    cv2.line(frame, analysis.left_eye_center, analysis.right_eye_center, (255, 255, 0), 2)
    cv2.line(frame, analysis.eye_midpoint, analysis.nose_tip, (0, 255, 255), 2)
    cv2.line(frame, analysis.eye_midpoint, analysis.mouth_center, (180, 180, 180), 1)

    left_eye_state = "closed" if analysis.left_eye_closed else "open"
    right_eye_state = "closed" if analysis.right_eye_closed else "open"
    mouth_state = "open" if analysis.mouth_open else "closed"
    calibration_text = (
        "Calibration: ready"
        if analysis.calibrated
        else f"Calibration: {analysis.calibration_progress}/{analysis.calibration_target}"
    )

    # 左上角文字用来实时显示姿态、EAR 和校准进度。
    text_lines = [
        f"yaw: {analysis.yaw:.4f}",
        f"pitch: {analysis.pitch:.4f}",
        f"L EAR: {analysis.left_eye_ear:.3f} ({left_eye_state})",
        f"R EAR: {analysis.right_eye_ear:.3f} ({right_eye_state})",
        f"Mouth: {analysis.mouth_open_ratio:.3f} ({mouth_state})",
        calibration_text,
    ]

    if gesture_text:
        text_lines.append(gesture_text)

    for line_index, text in enumerate(text_lines):
        y = 30 + line_index * 28
        cv2.putText(
            frame,
            text,
            (20, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 255, 0),
            2,
        )

    return frame
