import math
import time
from collections import deque
from typing import Optional, Tuple

import pyautogui

from smooth import AdaptiveMotionSmoother, OneEuroFilter


class HeadMouseController:
    """
    头控鼠标控制器。

    它负责把 `yaw / pitch` 这样的头部姿态信号转换成真实的鼠标移动，
    同时把左右眼闭合手势转换成单击和双击。
    """

    def __init__(
        self,
        sensitivity_x: float = 320.0,
        sensitivity_y: float = 320.0,
        deadzone: float = 0.012,
        max_step: float = 40.0,
        acceleration: float = 2.0,
        single_eye_closed_hold_time: float = 0.10,
        double_click_hold: float = 0.80,
        adaptive_learning: bool = True,
        left_edge_hold_seconds: float = 5.0,
        left_edge_margin_px: int = 2,
        scroll_deadzone: float = 0.12,
        scroll_sensitivity: float = 24.0,
        scroll_step_limit: int = 4,
        mouth_toggle_cooldown: float = 0.80,
        scroll_toggle_settle_seconds: float = 0.25,
        enabled: bool = True,
    ):
        # sensitivity_x / sensitivity_y:
        #     把头部姿态偏移换算成鼠标水平、垂直移动量时使用的基础放大倍数。
        # deadzone:
        #     输入软死区阈值，小于该值的轻微头抖会被视为噪声。
        # max_step:
        #     单帧允许发送给系统的最大像素位移，避免姿态突变时鼠标猛跳。
        # acceleration:
        #     非线性整形强度，用来让小动作更细、大动作更积极。
        # single_eye_closed_hold_time:
        #     单眼闭合多久才确认触发单击，防止自然眨眼误触。
        # double_click_hold:
        #     双眼同时闭合多久后触发双击。
        # enabled:
        #     控制器总开关，fail-safe 触发后会被关闭。
        # scroll_deadzone / scroll_sensitivity / scroll_step_limit:
        #     这一组参数只在“滚轮模式”里生效。
        #     它们分别控制：
        #     1. 多大幅度的抬头 / 低头才开始滚动；
        #     2. 满量程头部动作会滚多快；
        #     3. 单帧最多滚多少，避免页面一下跳太远。
        # mouth_toggle_cooldown / scroll_toggle_settle_seconds:
        #     这两个参数共同负责把“张嘴切模式”做稳：
        #     前者防止连续误切，后者防止切换手势本身立刻触发滚轮。
        self.sensitivity_x = sensitivity_x
        self.sensitivity_y = sensitivity_y
        self.deadzone = deadzone
        self.max_step = max_step
        self.acceleration = acceleration
        self.single_eye_closed_hold_time = single_eye_closed_hold_time
        self.double_click_hold = double_click_hold
        self.adaptive_learning = adaptive_learning
        self.scroll_deadzone = scroll_deadzone
        self.scroll_sensitivity = scroll_sensitivity
        self.scroll_step_limit = max(1, int(scroll_step_limit))
        self.mouth_toggle_cooldown = mouth_toggle_cooldown
        self.scroll_toggle_settle_seconds = scroll_toggle_settle_seconds
        # Windows 原生鼠标滚轮事件通常以 120 作为一个“标准滚轮刻度”。
        # 这意味着如果我们只把 1、2、3 这种很小的值直接发给系统，
        # 很多程序看起来就像“根本没有滚动”。
        # 所以这里把算法内部的“滚轮步数”再映射成真正发给系统的 Windows 滚轮增量。
        self.scroll_wheel_delta = 120
        # left_edge_hold_seconds:
        #     鼠标需要在左边界连续停留多久，才自动回到屏幕中心。
        # left_edge_margin_px:
        #     把距离屏幕左边多少像素以内视为“已经贴到左边界”。
        # left_edge_hold_seconds:
        #     鼠标在水平边界连续停留多久后，自动回到屏幕中心。
        #     当前实现会把左边界和右边界都按同一套秒数处理。
        self.left_edge_hold_seconds = left_edge_hold_seconds
        # left_edge_margin_px:
        #     距离屏幕左右边缘多少像素以内，视为已经贴边。
        self.left_edge_margin_px = left_edge_margin_px
        self.enabled = enabled

        # 滚轮模式状态。
        # scroll_mode_enabled:
        #     False 表示当前还是普通鼠标移动模式；
        #     True 表示已经切换成“抬头 / 低头滚轮”的模式。
        # last_mouth_open:
        #     只在嘴巴从“闭合”变成“张开”的那个上升沿切一次模式，
        #     而不是嘴巴一直张着时每一帧都切。
        # scroll_mode_ready_timestamp:
        #     切到滚轮模式后，先等一小段时间再允许真正滚动，
        #     避免切换动作自身导致页面立刻误滚。
        self.scroll_mode_enabled = False
        self.last_mouth_open = False
        self.last_mouth_toggle_timestamp = -1e9
        self.scroll_mode_ready_timestamp = 0.0

        # 左边界保护状态。
        # `left_edge_since` 记录鼠标已经连续停在左边界多久，
        # 达到阈值后就会自动把光标放回屏幕中心。
        self.left_edge_since: Optional[float] = None
        self.right_edge_since: Optional[float] = None

        # 这组参数始终保存“最初的基础配置”，供自动注视校准重新计算推荐值。
        self.default_sensitivity_x = sensitivity_x
        self.default_sensitivity_y = sensitivity_y
        self.default_deadzone = deadzone
        self.default_max_step = max_step
        self.default_acceleration = acceleration

        # 在线自适应学习配置。
        # 这套逻辑不会去“记最大值”，而是持续统计近期有效动作样本的高分位数，
        # 固定控制范围缩放系数。
        # 当前版本不再在线学习动作范围，而是把基础 deadzone 映射成一组稳定控制跨度。
        self.range_scale_x = 6.0
        self.range_scale_y = 7.0

        # 动态死区会根据静止时的抖动噪声自动调整，避免每次都手调 deadzone。
        # 这一组参数负责“动态死区”。
        # 运行时会观察你静止不动时的自然抖动，再反推出现在应该用多大的死区。
        self.noise_window_size = 90
        # 把估计到的噪声放大成真正控制用死区的系数。
        self.deadzone_noise_scale = 3.2
        # 动态死区变化的平滑系数，防止当前死区一帧一跳。
        self.deadzone_update_alpha = 0.18
        # 只有超过“动态死区 + 额外边距”的动作，才被当成真正的学习样本。

        # 给在线学习设置合理边界，防止偶发跳点把控制尺度拉得过大或过小。
        # 在线学习也需要边界，避免学得过大或过小。
        self.min_range_x = max(deadzone * 4.5, 0.045)
        self.max_range_x = 0.30
        self.min_range_y = max(deadzone * 5.0, 0.055)
        self.max_range_y = 0.35
        # 动态死区只允许在原始 deadzone 的基础上变大，不允许学得比原始值更敏感。
        self.min_deadzone = deadzone
        self.max_deadzone = max(deadzone * 3.0, 0.045)

        # 初始范围不是从 0 开始，而是给一组保守默认值兜底。
        initial_range_x = max(deadzone * self.range_scale_x, 0.070)
        initial_range_y = max(deadzone * self.range_scale_y, 0.085)

        # 左右上下四个方向分开学习，因为人的动作能力通常并不对称。
        self.learned_range_left = initial_range_x
        self.learned_range_right = initial_range_x
        self.learned_range_up = initial_range_y
        self.learned_range_down = initial_range_y

        # 当前真正参与控制的动态死区，会在运行时持续缓慢变化。
        self.current_deadzone_x = deadzone
        self.current_deadzone_y = deadzone

        # 静止偏差补偿参数。
        # 作用是把“用户看起来在正视，但姿态值仍然有一点常驻偏移”的那一部分慢慢吸收掉，
        # 避免这些低频残余偏差在速度控制链里变成持续漂移。
        # bias 学习进一步收慢，并要求更接近静止才允许更新，避免中心补偿追着噪声漂。
        self.bias_compensation_alpha = 0.02
        self.bias_speed_limit = 0.45
        self.bias_rest_frames_required = 8
        self.max_bias_x = max(deadzone * 2.5, 0.028)
        self.max_bias_y = max(deadzone * 2.8, 0.034)
        self.pose_bias_x = 0.0
        self.pose_bias_y = 0.0
        self.bias_rest_count_x = 0
        self.bias_rest_count_y = 0

        # 输出锁定区参数。
        # 这里不是替代前面的动态死区，而是在归一化之后再加一道“稳态锁”：
        # 只有偏差真正明显到超过释放阈值，鼠标才从静止状态起步。
        # 输出锁也略微放宽，让中性位附近更容易被“锁住不动”。
        self.output_lock_deadzone = 0.040
        self.output_release_deadzone = 0.070
        self.output_lock_x = True
        self.output_lock_y = True

        # 自适应输出压缩参数。
        # 自适应归一化会把姿态映射到统一尺度，这对“学死区、学中心”有好处，
        # 但如果直接把这个归一化值送进后面的加速链，精确点位控制会变难。
        # 所以这里额外加一层“中心更细、边缘更保守”的压缩曲线。
        # adaptive_output_gain_x / adaptive_output_gain_y:
        #     分别控制横向、纵向在进入压缩曲线后的总体输出强度。
        #     它们越小，自适应模式下鼠标越稳，但也会更慢。
        # adaptive_precision_exponent:
        #     压缩曲线的指数。大于 1 时，中心附近的输出会被明显压小，
        #     这样同样一点点头动不会立刻变成明显位移，更适合点按钮、点输入框这类精确操作。
        # adaptive_output_limit:
        #     给压缩后的自适应输出再加一个绝对上限，防止归一化后的大幅动作重新把速度推得过高。
        self.adaptive_output_gain_x = 0.42
        self.adaptive_output_gain_y = 0.34
        self.adaptive_precision_exponent = 1.85
        self.adaptive_output_limit = 0.58

        # 噪声窗口记录“接近静止”的姿态，范围窗口记录“超过死区”的有效动作。
        self.noise_samples_x = deque(maxlen=self.noise_window_size)
        self.noise_samples_y = deque(maxlen=self.noise_window_size)

        # 保存上一帧姿态和时间，供速度估计与跳点过滤使用。
        self.last_pose_x = 0.0
        self.last_pose_y = 0.0
        self.last_pose_timestamp: Optional[float] = None

        # motion_smoother 负责在像素层面对鼠标位移再做一次平滑，
        # 把头部姿态估计里的高频抖动尽量压下去。
        self.motion_smoother = AdaptiveMotionSmoother(
            min_cutoff=1.2,
            beta=0.28,
            d_cutoff=1.0,
            idle_threshold=1.0,
            idle_damping=0.35,
        )

        # 滚轮不直接复用鼠标像素平滑器，而是单独维护一套一维滤波。
        # 原因是滚轮的输出单位不是像素，而是“滚轮刻度”，手感更像速度积分而不是位置跟随。
        self.scroll_filter = OneEuroFilter(
            min_cutoff=1.8,
            beta=0.25,
            d_cutoff=1.0,
        )

        # 鼠标 API 只能发送整数像素位移，这里保存浮点尾差，避免精度损失。
        self.remainder_x = 0.0
        # remainder_x / remainder_y:
        #     记录每一帧四舍五入后剩下的小数像素尾差，后续会继续累计。
        self.remainder_y = 0.0

        # scroll_remainder:
        #     记录滚轮速度积分后还不够 1 个滚轮单位的小数尾差。
        # last_scroll_timestamp:
        #     用来把“每秒滚动速度”换算成“这一帧应该积累多少滚轮量”。
        self.scroll_remainder = 0.0
        self.last_scroll_timestamp: Optional[float] = None

        # 眼动点击状态机。
        # 下面这组状态共同实现“闭眼点击状态机”：
        # - *_since 记录某个闭眼动作已经持续了多久
        # - *_sent 防止同一轮闭眼持续过程中重复发出点击
        # - wait_for_full_open 用于要求双击后必须完全睁眼再重新进入识别
        self.left_only_since: Optional[float] = None
        self.right_only_since: Optional[float] = None
        self.both_closed_since: Optional[float] = None

        self.left_click_sent = False
        self.right_click_sent = False
        self.double_click_sent = False
        self.wait_for_full_open = False

        self.eye_state_text = "No face"
        self.last_action_text = "None"
        self.last_action_timestamp = 0.0

        # FAILSAFE=True:
        #     鼠标被移到屏幕角落时，pyautogui 会抛异常，避免控制失控。
        # PAUSE=0:
        #     关闭 pyautogui 默认的动作间等待，减少控制延迟。
        # 关闭 PyAutoGUI 自带的立刻 fail-safe，改由我们自己处理左边界停留回中。
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0
        self._reset_adaptive_learning()

    # 把当前默认基线参数整理成字典，交给 focus 校准模块作为调参起点。
    def get_focus_base_profile(self) -> dict:
        """返回给注视校准器使用的基础鼠标参数。"""
        return {
            "sensitivity_x": self.default_sensitivity_x,
            "sensitivity_y": self.default_sensitivity_y,
            "deadzone": self.default_deadzone,
            "max_step": self.default_max_step,
            "acceleration": self.default_acceleration,
        }

    # profile 是校准模块根据 10 秒采样结果构造的推荐参数集合。
    # 这里应用的是“当前运行参数”，不会覆盖 default_* 里保存的基线值。
    def apply_focus_calibration(self, profile, timestamp: Optional[float] = None):
        """应用注视校准后推荐的新参数。"""
        if timestamp is None:
            timestamp = time.time()

        self.sensitivity_x = profile.recommended_sensitivity_x
        self.sensitivity_y = profile.recommended_sensitivity_y
        self.deadzone = profile.recommended_deadzone
        self.max_step = profile.recommended_max_step
        self.acceleration = profile.recommended_acceleration

        # 应用启动校准的新基础参数后，要把在线学习状态同步清零。
        # 否则上一轮的中心补偿和动态死区会继续影响这一轮控制。
        self._reset_adaptive_learning()
        self.reset_motion()
        self.reset_eye_gesture_state(no_face=False)
        self._remember_action("Focus calibration applied", timestamp)

    # fail-safe 触发后控制器会被禁用。
    # 重新启用时除了打开 enabled，还要把旧的运动和平滑历史一并清空。
    def reenable(self, timestamp: Optional[float] = None):
        """在 fail-safe 触发后，手动重新启用鼠标控制。"""
        if timestamp is None:
            timestamp = time.time()

        self.enabled = True
        self.reset_motion()
        self.reset_eye_gesture_state(no_face=False)
        self.eye_state_text = "Controller enabled"
        self._remember_action("Controller enabled", timestamp)

    # 统一维护“最近一次动作描述”，供调试文字与状态提示复用。
    def _remember_action(self, text: str, timestamp: float) -> str:
        """记录最近一次操作，供调试文本显示。"""
        self.last_action_text = text
        self.last_action_timestamp = timestamp
        return text

    # 真正的系统鼠标移动只从这里发出，这样可以统一处理 fail-safe。
    def _safe_move_rel(self, move_x: int, move_y: int):
        """安全地发送相对鼠标移动，捕获 PyAutoGUI fail-safe。"""
        if not self.enabled:
            return

        try:
            pyautogui.moveRel(move_x, move_y, duration=0)
        except pyautogui.FailSafeException:
            # 理论上当前项目已经关闭了 PyAutoGUI 自带 fail-safe。
            # 这里保留兜底分支：一旦仍然触发，就改成自动回中，而不是直接失效。
            self.reset_motion()
            self.center_cursor(time.time())
            self._remember_action("Fail-safe centered cursor", time.time())

    # button 指定左右键，clicks 指定单击还是双击。
    # 所有点击动作同样走统一的安全包装。
    def _safe_click(self, button: str, clicks: int = 1):
        """安全地发送鼠标点击。"""
        if not self.enabled:
            return

        try:
            pyautogui.click(button=button, clicks=clicks, interval=0.12)
        except pyautogui.FailSafeException:
            # 点击阶段如果意外触发 fail-safe，也按同样策略处理：
            # 自动回中，而不是把整个控制器禁用。
            self.reset_motion()
            self.center_cursor(time.time())
            self._remember_action("Fail-safe centered cursor", time.time())

    def _safe_scroll(self, clicks: int):
        """
        安全地发送滚轮事件。

        这里和鼠标移动、鼠标点击一样，统一用一层保护包装起来。
        一旦底层库仍然意外抛出 fail-safe 异常，就走“清空状态并回中”的兜底逻辑，
        而不是把控制器直接搞到不可恢复。
        """
        if not self.enabled or clicks == 0:
            return

        try:
            # 注意这里不能直接把算法内部的 1 / -1 步数原样发给 Windows。
            # Windows 鼠标滚轮消息的常用标准刻度是 120；
            # 如果只发 1、2、3 这种很小的增量，很多应用表面上会完全没有反应。
            # 因此这里把“滚轮步数”先换算成更符合 Windows 轮播事件习惯的真实增量。
            pyautogui.scroll(int(clicks * self.scroll_wheel_delta))
        except pyautogui.FailSafeException:
            self.reset_motion()
            self.center_cursor(time.time())
            self._remember_action("Fail-safe centered cursor", time.time())

    def handle_mouth_toggle(self, mouth_open: bool, timestamp: Optional[float] = None) -> bool:
        """
        根据“稳定后的张嘴状态”切换滚轮模式。

        这层逻辑只在嘴巴从“闭合”变成“张开”的上升沿切一次模式：
        - 第一次大张嘴: 进入滚轮模式
        - 再次大张嘴: 退回普通鼠标模式

        返回值:
        - True: 这一帧刚刚完成了模式切换
        - False: 这一帧没有切换
        """
        if timestamp is None:
            timestamp = time.time()

        toggled = False
        rising_edge = mouth_open and not self.last_mouth_open

        if rising_edge and (timestamp - self.last_mouth_toggle_timestamp) >= self.mouth_toggle_cooldown:
            self.scroll_mode_enabled = not self.scroll_mode_enabled
            self.last_mouth_toggle_timestamp = timestamp
            self.scroll_mode_ready_timestamp = timestamp + self.scroll_toggle_settle_seconds

            # 切模式时先清空上一种输出链路留下的尾差和滤波历史。
            # 这样可以避免“刚切到滚轮模式时，上一帧的鼠标位移残留”或反过来“上一帧的滚轮残留”带到新模式里。
            self.reset_motion()

            if self.scroll_mode_enabled:
                self._remember_action("Scroll mode enabled", timestamp)
            else:
                self._remember_action("Mouse mode enabled", timestamp)
            toggled = True

        self.last_mouth_open = mouth_open
        return toggled

    # 启动校准前先把鼠标归位到屏幕中心，避免一开始就在角落触发 fail-safe。
    def center_cursor(self, timestamp: Optional[float] = None) -> bool:
        """把光标放到屏幕中心。"""
        if timestamp is None:
            timestamp = time.time()

        screen_width, screen_height = pyautogui.size()
        center_x = screen_width // 2
        center_y = screen_height // 2

        original_failsafe = pyautogui.FAILSAFE
        try:
            pyautogui.FAILSAFE = False
            pyautogui.moveTo(center_x, center_y, duration=0)
            self.left_edge_since = None
            self.right_edge_since = None
            self._remember_action("Cursor centered", timestamp)
            return True
        except pyautogui.FailSafeException:
            self.reset_motion()
            self._remember_action("Fail-safe blocked centering", time.time())
            return False
        finally:
            pyautogui.FAILSAFE = original_failsafe

    def monitor_left_edge_recenter(self, timestamp: Optional[float] = None) -> bool:
        """
        监控鼠标是否持续停留在左右边界，达到阈值后自动回中。

        这套逻辑用来代替旧版“碰到边界立刻失效”的行为，
        让用户在光标卡到左侧或右侧时都能平稳恢复。
        """
        if timestamp is None:
            timestamp = time.time()

        cursor_x, _ = pyautogui.position()
        screen_width, _ = pyautogui.size()
        at_left_edge = cursor_x <= self.left_edge_margin_px
        at_right_edge = cursor_x >= (screen_width - 1 - self.left_edge_margin_px)

        # 左边界分支:
        # 只在持续贴边达到阈值后才回中，中途一旦离开边界就会重新计时。
        if at_left_edge:
            if self.left_edge_since is None:
                self.left_edge_since = timestamp
            self.right_edge_since = None

            if (timestamp - self.left_edge_since) < self.left_edge_hold_seconds:
                return False

            self.reset_motion()
            self.left_edge_since = None
            self.right_edge_since = None

            centered = self.center_cursor(timestamp)
            if centered:
                self._remember_action("Held left edge 5s, cursor centered", timestamp)
            return centered

        # 右边界分支与左边界完全对称，使用相同的停留时长和边距阈值。
        if at_right_edge:
            if self.right_edge_since is None:
                self.right_edge_since = timestamp
            self.left_edge_since = None

            if (timestamp - self.right_edge_since) < self.left_edge_hold_seconds:
                return False

            self.reset_motion()
            self.left_edge_since = None
            self.right_edge_since = None

            centered = self.center_cursor(timestamp)
            if centered:
                self._remember_action("Held right edge 5s, cursor centered", timestamp)
            return centered

        # 不在任何一侧边界时，左右计时都清零。
        self.left_edge_since = None
        self.right_edge_since = None
        return False

    def _reset_scroll_state(self):
        """
        清空滚轮平滑历史、速度积分尾差和时间基准。

        这一步通常会在以下场景一起发生：
        - 切换滚轮模式
        - 人脸丢失
        - 自动校准进行中
        - 需要把鼠标 / 滚轮的历史残留全部清掉
        """
        self.scroll_filter.reset()
        self.scroll_remainder = 0.0
        self.last_scroll_timestamp = None

    # 清空鼠标位移平滑历史和小数尾差，防止旧惯性延续到新一轮控制里。
    def reset_motion(self):
        """清空鼠标移动和滚轮输出两条链路的平滑历史与尾差。"""
        self.motion_smoother.reset()
        self._reset_scroll_state()
        self.remainder_x = 0.0
        self.remainder_y = 0.0

    # 只重置闭眼点击相关状态，不负责重置鼠标移动平滑。
    def reset_eye_gesture_state(self, no_face: bool = False):
        """重置眼动点击状态机。"""
        self.left_only_since = None
        self.right_only_since = None
        self.both_closed_since = None

        self.left_click_sent = False
        self.right_click_sent = False
        self.double_click_sent = False
        self.wait_for_full_open = False

        self.eye_state_text = "No face" if no_face else "Both eyes open"

    # 没检测到脸时，继续沿用上一次平滑结果会导致鼠标漂移，所以这里统一清零。
    def handle_no_face(self):
        """在人脸丢失时统一清空运动和点击状态。"""
        self.reset_motion()
        self.reset_eye_gesture_state(no_face=True)

    # 软死区和“直接砍成 0 的硬死区”不同：
    # 它会在超过阈值后把剩余区间重新拉伸，避免刚越过阈值时突然跳变。
    def apply_soft_deadzone(self, value: float) -> float:
        """
        软死区处理。

        很小的姿态偏移直接视为 0，超过死区后再线性映射回 0~1。
        """
        magnitude = abs(value)
        if magnitude <= self.deadzone:
            return 0.0

        adjusted = (magnitude - self.deadzone) / max(1.0 - self.deadzone, 1e-6)
        return math.copysign(adjusted, value)

    # 输入整形用于兼顾“中间稳”和“边缘快”：
    # 中心附近的小动作更细腻，偏离中心越大增长越快。
    def shape_input(self, value: float) -> float:
        """
        非线性输入整形。

        小幅动作更细腻，大幅动作更积极。
        """
        magnitude = abs(value)
        shaped = magnitude * (1.0 + self.acceleration * magnitude)
        return math.copysign(shaped, value)

    @staticmethod
    # 简单限幅工具，避免位移或参数超出允许范围。
    def clamp(value: float, min_value: float, max_value: float) -> float:
        """把数值限制在给定范围内。"""
        return max(min_value, min(max_value, value))

    @staticmethod
    def _quantile(samples, quantile: float) -> float:
        """
        计算样本序列的分位数。

        这里不用最大值，是因为一次异常跳点就可能把范围拉得很夸张。
        改用分位数后，我们可以更稳定地逼近“用户平时常用的动作上限”。
        例如:
        - 0.5 表示中位数
        - 0.9 表示第 90 百分位
        """
        if not samples:
            return 0.0

        ordered = sorted(samples)
        if len(ordered) == 1:
            return ordered[0]

        position = (len(ordered) - 1) * quantile
        lower_index = int(math.floor(position))
        upper_index = int(math.ceil(position))

        if lower_index == upper_index:
            return ordered[lower_index]

        fraction = position - lower_index
        return ordered[lower_index] * (1.0 - fraction) + ordered[upper_index] * fraction

    @classmethod
    def _robust_noise(cls, samples) -> float:
        """
        用稳健统计方式估计噪声大小。

        这里用的是 MAD(Median Absolute Deviation，中位绝对偏差)。
        相比普通标准差，它更不容易被少数异常值带偏，
        所以更适合摄像头姿态估计这种偶尔会跳点的信号。
        """
        if not samples:
            return 0.0

        center = cls._quantile(samples, 0.5)
        deviations = [abs(sample - center) for sample in samples]
        return cls._quantile(deviations, 0.5) * 1.4826

    def _reset_adaptive_learning(self):
        """
        重置自适应学习状态。

        调用场景:
        - 控制器刚初始化时
        - 启动校准结束，应用新基础参数后

        这样做的目的是让新的基础参数成为下一轮学习的起点，
        避免把旧环境、旧姿态习惯继续带到新的控制阶段。
        """
        # 固定控制范围会跟着新的基础 deadzone 一起重建，
        # 但运行过程中不会再被短时动作样本持续改写。
        initial_range_x = max(self.deadzone * self.range_scale_x, self.min_range_x)
        initial_range_y = max(self.deadzone * self.range_scale_y, self.min_range_y)

        self.learned_range_left = self.clamp(initial_range_x, self.min_range_x, self.max_range_x)
        self.learned_range_right = self.clamp(initial_range_x, self.min_range_x, self.max_range_x)
        self.learned_range_up = self.clamp(initial_range_y, self.min_range_y, self.max_range_y)
        self.learned_range_down = self.clamp(initial_range_y, self.min_range_y, self.max_range_y)

        self.current_deadzone_x = self.clamp(self.deadzone, self.min_deadzone, self.max_deadzone)
        self.current_deadzone_y = self.clamp(self.deadzone, self.min_deadzone, self.max_deadzone)

        self.noise_samples_x.clear()
        self.noise_samples_y.clear()

        self.last_pose_x = 0.0
        self.last_pose_y = 0.0
        self.last_pose_timestamp = None
        self.pose_bias_x = 0.0
        self.pose_bias_y = 0.0
        self.bias_rest_count_x = 0
        self.bias_rest_count_y = 0
        self.output_lock_x = True
        self.output_lock_y = True

    def _update_adaptive_state(self, yaw: float, pitch: float, timestamp: float):
        """
        用当前帧姿态更新在线学习状态。

        这个方法本身不直接移动鼠标，它只负责维护控制器的“认知”：
        - 当前静止噪声大概有多大
        - 当前动态死区应该设成多少
        - 当前中性位还残留多少固定偏差

        整个过程分为四步:
        1. 过滤明显跳点
        2. 识别静止样本并估计噪声
        3. 更新动态死区
        4. 慢速修正中心偏差
        """
        if not self.adaptive_learning:
            self.current_deadzone_x = self.deadzone
            self.current_deadzone_y = self.deadzone
            return

        # 先用当前累计出来的静止偏差去抵消输入。
        # 这样后面的噪声学习、范围学习和最终输出，
        # 都尽量围绕更贴近真实中性头位的姿态来进行。
        compensated_yaw = yaw - self.pose_bias_x
        compensated_pitch = pitch - self.pose_bias_y

        # 第一帧只有建立基准的意义，还无法计算速度和跳点，
        # 所以先记住当前位置，下一帧再开始学习。
        if self.last_pose_timestamp is None:
            self.last_pose_x = compensated_yaw
            self.last_pose_y = compensated_pitch
            self.last_pose_timestamp = timestamp
            return

        # dt 是两帧时间差，delta_x / delta_y 是姿态变化量。
        # 后面会用它们判断当前帧更像静止抖动、正常动作还是异常跳变。
        dt = max(timestamp - self.last_pose_timestamp, 1e-6)
        delta_x = abs(compensated_yaw - self.last_pose_x)
        delta_y = abs(compensated_pitch - self.last_pose_y)

        # 如果这一帧变化量远大于当前固定控制范围，
        # 更像是跟踪跳点而不是真实头部动作，这种样本不参与自适应更新。
        jump_limit_x = max(self.learned_range_left, self.learned_range_right) * 1.8
        jump_limit_y = max(self.learned_range_up, self.learned_range_down) * 1.8
        jump_ok = delta_x <= jump_limit_x and delta_y <= jump_limit_y

        # “接近静止”判定:
        # 只有姿态离中心不远，而且单位时间变化速度也够小，
        # 才把该帧记为噪声样本，用来学习动态死区。
        rest_limit_x = max(self.deadzone * 2.5, min(self.learned_range_left, self.learned_range_right) * 0.35)
        rest_limit_y = max(self.deadzone * 2.5, min(self.learned_range_up, self.learned_range_down) * 0.35)
        speed_x = delta_x / dt
        speed_y = delta_y / dt

        # 只有连续多帧都满足“接近静止”的条件，才允许修正中心偏差。
        # 这样可以明显减少短时检测抖动把 bias 一点点带偏的情况。
        resting_x = jump_ok and abs(compensated_yaw) <= rest_limit_x and speed_x <= self.bias_speed_limit
        resting_y = jump_ok and abs(compensated_pitch) <= rest_limit_y and speed_y <= self.bias_speed_limit
        self.bias_rest_count_x = self.bias_rest_count_x + 1 if resting_x else 0
        self.bias_rest_count_y = self.bias_rest_count_y + 1 if resting_y else 0

        # 只有在“接近静止、速度也不大”的情况下，才慢慢修正静止偏差。
        # 这一步相当于让控制器逐渐学会“我明明正视时，姿态里还残留多少固定误差”，
        # 可以专门消掉那种长期稳定、方向固定的小偏差，减少鼠标持续慢漂。
        if self.bias_rest_count_x >= self.bias_rest_frames_required:
            self.pose_bias_x = self.clamp(
                self.pose_bias_x + compensated_yaw * self.bias_compensation_alpha,
                -self.max_bias_x,
                self.max_bias_x,
            )
        if self.bias_rest_count_y >= self.bias_rest_frames_required:
            self.pose_bias_y = self.clamp(
                self.pose_bias_y + compensated_pitch * self.bias_compensation_alpha,
                -self.max_bias_y,
                self.max_bias_y,
            )

        # bias 更新后，再重新计算一次补偿后的姿态。
        # 后续噪声估计、范围学习和上一帧缓存看到的，就都是更贴近真实中性位的值。
        compensated_yaw = yaw - self.pose_bias_x
        compensated_pitch = pitch - self.pose_bias_y

        if jump_ok and abs(compensated_yaw) <= rest_limit_x and speed_x <= 1.2:
            self.noise_samples_x.append(compensated_yaw)
        if jump_ok and abs(compensated_pitch) <= rest_limit_y and speed_y <= 1.2:
            self.noise_samples_y.append(compensated_pitch)

        # 目标死区由“基础死区保底值 + 运行时噪声估计”共同组成。
        # 噪声越大，目标死区就越大；噪声越小，目标死区会逐渐回落。
        target_deadzone_x = self.clamp(
            max(
                self.deadzone,
                self.deadzone + self.deadzone_noise_scale * self._robust_noise(self.noise_samples_x),
            ),
            self.min_deadzone,
            self.max_deadzone,
        )
        target_deadzone_y = self.clamp(
            max(
                self.deadzone,
                self.deadzone + self.deadzone_noise_scale * self._robust_noise(self.noise_samples_y),
            ),
            self.min_deadzone,
            self.max_deadzone,
        )

        # 当前死区不直接跳到目标值，而是慢慢靠过去。
        # 这样手感不会忽大忽小。
        self.current_deadzone_x += (target_deadzone_x - self.current_deadzone_x) * self.deadzone_update_alpha
        self.current_deadzone_y += (target_deadzone_y - self.current_deadzone_y) * self.deadzone_update_alpha

        # 到这里为止，当前帧已经完成了“跳点过滤 + 噪声估计 + 中心补偿”。
        # 后续不再在线学习范围，只保留固定控制跨度。
        # 当前版本不再在线学习动作范围。
        # 归一化使用的是固定控制范围，运行中只更新中心偏差和动态死区。
        # 这样可以避免把最近几秒的小动作或短时抖动误学成“用户动作幅度变小”。

        # 保存当前帧，供下一帧继续计算速度、跳点和静止噪声。
        self.last_pose_x = compensated_yaw
        self.last_pose_y = compensated_pitch
        self.last_pose_timestamp = timestamp

    def _normalize_adaptive_pose(
        self,
        value: float,
        negative_range: float,
        positive_range: float,
        deadzone: float,
    ) -> float:
        """
        按当前动态死区和固定控制范围，把单轴姿态归一化到 [-1, 1]。

        映射规则:
        - 落在死区内: 视为 0，不移动
        - 超过死区后: 按当前方向固定控制范围做线性映射
        - 左右、上下分别使用各自独立的固定跨度

        这样后面的鼠标控制面对的就不再是“绝对姿态值”，
        而是“相对这个用户当前动作能力的归一化控制量”。
        """
        if value >= 0.0:
            if value <= deadzone:
                return 0.0

            usable_span = max(positive_range - deadzone, 1e-6)
            return self.clamp((value - deadzone) / usable_span, 0.0, 1.0)

        magnitude = abs(value)
        if magnitude <= deadzone:
            return 0.0

        usable_span = max(negative_range - deadzone, 1e-6)
        return -self.clamp((magnitude - deadzone) / usable_span, 0.0, 1.0)

    def _apply_output_lock(self, value: float, locked: bool) -> Tuple[float, bool]:
        """
        给归一化后的控制量再加一道稳态锁。

        作用:
        - 已经静止时，只有偏差明显超过释放阈值才重新起步
        - 已经运动时，只要重新回到较小范围就再次锁住
        - 通过滞回减少临界点来回抖动
        """
        magnitude = abs(value)

        if locked:
            if magnitude <= self.output_release_deadzone:
                return 0.0, True
            return value, False

        if magnitude <= self.output_lock_deadzone:
            return 0.0, True

        return value, False

    def _compress_adaptive_output(self, value: float, gain: float) -> float:
        """
        对自适应归一化后的控制量再做一次精细压缩。

        目的:
        - 保留统一尺度带来的稳定性
        - 明显压低中心区域的输出，方便精准停点
        - 给自适应模式单独设一个更保守的最高输出上限
        """
        magnitude = abs(value)
        if magnitude <= 1e-6:
            return 0.0

        # 先用指数曲线压缩中心附近的输出，再乘以方向专属 gain。
        # 这里不是线性缩小，而是“越接近中心压得越狠，越远离中心保留得越多”，
        # 这样既能维持大动作扫屏，又能让小动作停点更容易控制。
        compressed = math.pow(magnitude, self.adaptive_precision_exponent) * gain
        # 最后再做一次硬上限，避免自适应模式在某些极端姿态下重新显得太快。
        compressed = min(compressed, self.adaptive_output_limit)
        return math.copysign(compressed, value)

    # 头控鼠标主流程：
    # 1. 姿态软死区
    # 2. 非线性整形
    # 3. 乘灵敏度得到理论像素位移
    # 4. 交给平滑器抑制抖动
    # 5. 限幅并累计小数尾差
    # 6. 向系统发送整数像素移动
    def update(self, yaw: float, pitch: float, timestamp: Optional[float] = None) -> Tuple[int, int]:
        """根据头部姿态更新鼠标位移。"""
        if not self.enabled:
            return 0, 0

        if timestamp is None:
            timestamp = time.time()

        # 第一步: 更新在线学习状态。
        # 这一步只负责“学习”，不会直接输出鼠标位移。
        self._update_adaptive_state(yaw, pitch, timestamp)
        # 将在线估计到的静止偏差应用到当前输入，再进入后续归一化。
        compensated_yaw = yaw - self.pose_bias_x
        compensated_pitch = pitch - self.pose_bias_y

        if self.adaptive_learning:
            # 第二步: 根据当前动态死区和固定控制范围，把姿态归一化。
            # 归一化之后，后面的控制链看到的是统一尺度的输入，而不是原始姿态值。
            adaptive_yaw = self._normalize_adaptive_pose(
                compensated_yaw,
                self.learned_range_left,
                self.learned_range_right,
                self.current_deadzone_x,
            )
            adaptive_pitch = self._normalize_adaptive_pose(
                compensated_pitch,
                self.learned_range_up,
                self.learned_range_down,
                self.current_deadzone_y,
            )
        else:
            # 回退路径: 如果关闭自适应学习，就继续使用旧版固定死区逻辑。
            adaptive_yaw = self.apply_soft_deadzone(compensated_yaw)
            adaptive_pitch = self.apply_soft_deadzone(compensated_pitch)

        # 第三步: 在归一化输出后增加“稳态锁”。
        # 只有偏差明显超过释放阈值才解除锁定，可显著减少中性位附近来回抖动。
        adaptive_yaw, self.output_lock_x = self._apply_output_lock(adaptive_yaw, self.output_lock_x)
        adaptive_pitch, self.output_lock_y = self._apply_output_lock(adaptive_pitch, self.output_lock_y)

        # 第四步: 对自适应输出做额外压缩。
        # 这一层只作用于“学习模式”的归一化结果，目的是把控制重点重新拉回中心细调。
        adaptive_yaw = self._compress_adaptive_output(adaptive_yaw, self.adaptive_output_gain_x)
        adaptive_pitch = self._compress_adaptive_output(adaptive_pitch, self.adaptive_output_gain_y)

        # 当双轴都处于锁定状态时，清掉累积残差并直接返回。
        # 这样不会出现“明明静止但小数尾差仍持续推着鼠标慢漂”的问题。
        if self.output_lock_x and self.output_lock_y:
            self.reset_motion()
            return 0, 0

        # yaw / pitch 先经过软死区，去掉头部自然微抖。
        yaw = self.apply_soft_deadzone(yaw)
        pitch = self.apply_soft_deadzone(pitch)
        # 为了尽量少改原有链路结构，下面继续复用 yaw / pitch 这两个变量名。
        # 但从这里开始，它们承载的是“自适应归一化后的控制量”，不是原始姿态值。
        yaw = adaptive_yaw
        pitch = adaptive_pitch

        # shaped_* 仍然是无单位控制量，只是经过了更适合手感的非线性整形。
        shaped_yaw = self.shape_input(yaw)
        # 第三步: 非线性整形。
        # 中心区域更细，边缘增长更快，兼顾微调和快速扫屏。
        shaped_pitch = self.shape_input(pitch)

        # raw_d* 才是这一帧理论上想移动的像素数。
        raw_dx = shaped_yaw * self.sensitivity_x
        # 第四步: 乘以基础速度尺度，得到理论像素位移。
        # 现在的 sensitivity 更像输出速度上限，不再是唯一的手感来源。
        raw_dy = shaped_pitch * self.sensitivity_y

        # smooth_* 用来进一步压掉姿态估计里的高频抖动。
        # 第五步: 像素级平滑，压掉高频抖动，减少“头没动但鼠标细晃”的感觉。
        smooth_dx, smooth_dy = self.motion_smoother.smooth(raw_dx, raw_dy, timestamp)

        # move_* 在真正发送前再次限幅，保证单帧速度可控。
        # 第六步: 单帧限幅，防止某一帧突然冲得过快。
        move_x = self.clamp(smooth_dx, -self.max_step, self.max_step)
        move_y = self.clamp(smooth_dy, -self.max_step, self.max_step)

        if abs(move_x) < 0.05 and abs(move_y) < 0.05:
            return 0, 0

        # 剩余不足 1 像素的量不会直接丢掉，而是留到下一帧继续累计。
        # 第七步: 把不足 1 像素的小数位移累积起来，避免精度白白丢掉。
        self.remainder_x += move_x
        self.remainder_y += move_y

        send_x = int(round(self.remainder_x))
        send_y = int(round(self.remainder_y))

        self.remainder_x -= send_x
        self.remainder_y -= send_y

        if send_x == 0 and send_y == 0:
            return 0, 0

        self._safe_move_rel(send_x, send_y)
        return send_x, send_y

    # 闭眼手势状态机：
    # - 左眼单独闭合并保持：左键单击
    # - 右眼单独闭合并保持：右键单击
    # - 双眼同时闭合并保持：左键双击
    def _apply_scroll_deadzone(self, value: float) -> float:
        """
        给滚轮专门加一层更保守的死区。

        鼠标移动允许比较细的中心微调，但滚轮通常不希望一低头一点点页面就开始滑。
        所以即使前面已经做过自适应死区和稳态锁，这里仍然再加一层“滚轮专用死区”。
        """
        magnitude = abs(value)
        if magnitude <= self.scroll_deadzone:
            return 0.0

        # 滚轮现在使用的是“压缩前的归一化垂直控制量”，它的自然满量程就是 1.0。
        # 因此这里的剩余可用区间也要按 1.0 来算，而不是沿用鼠标精细停点那套压缩上限。
        usable_span = max(1.0 - self.scroll_deadzone, 1e-6)
        adjusted = self.clamp((magnitude - self.scroll_deadzone) / usable_span, 0.0, 1.0)
        return math.copysign(adjusted, value)

    def _emit_scroll(self, control_pitch: float, timestamp: float) -> int:
        """
        把垂直控制量转换成滚轮输出。

        设计思路不是“每帧直接滚一下”，而是：
        1. 先给滚轮单独加更保守的死区
        2. 再做一维平滑
        3. 再把它解释成“每秒滚动速度”
        4. 最后按时间积分成这一帧应该滚多少

        这样做的好处是帧率变化时手感更稳定，也更容易停住。
        """
        if timestamp < self.scroll_mode_ready_timestamp:
            self._reset_scroll_state()
            return 0

        scroll_input = self._apply_scroll_deadzone(control_pitch)
        filtered_scroll_input = self.scroll_filter.filter(scroll_input, timestamp)

        if abs(scroll_input) <= 1e-6 and abs(filtered_scroll_input) < 0.02:
            filtered_scroll_input = 0.0

        if self.last_scroll_timestamp is None:
            self.last_scroll_timestamp = timestamp
            return 0

        dt = max(timestamp - self.last_scroll_timestamp, 1e-6)
        self.last_scroll_timestamp = timestamp

        shaped_scroll = self.shape_input(filtered_scroll_input)

        # PyAutoGUI 的滚轮方向约定是：
        # - 正数: 向上滚
        # - 负数: 向下滚
        # 而当前项目的 pitch 方向里，“低头”通常对应正方向，“抬头”对应负方向，
        # 所以这里取反后，才能得到“低头向下滚、抬头向上滚”的直觉映射。
        scroll_speed = -shaped_scroll * self.scroll_sensitivity
        self.scroll_remainder += scroll_speed * dt

        pending_steps = int(math.trunc(self.scroll_remainder))
        if pending_steps == 0:
            return 0

        send_steps = int(self.clamp(pending_steps, -self.scroll_step_limit, self.scroll_step_limit))
        self.scroll_remainder -= send_steps

        if send_steps == 0:
            return 0

        self._safe_scroll(send_steps)
        return send_steps

    def update_scroll_mode(self, yaw: float, pitch: float, timestamp: Optional[float] = None) -> Tuple[int, int]:
        """
        滚轮模式下的主流程。

        当前采用的约定是：
        - 左右转头仍然保留为鼠标横向移动，方便不离开当前位置做轻微横向修正
        - 抬头 / 低头不再推动鼠标纵向移动，而是改成滚轮向上 / 向下

        返回值:
        - 第一个整数: 这一帧实际发送出去的横向鼠标像素
        - 第二个整数: 这一帧实际发送出去的滚轮单位
        """
        if not self.enabled:
            return 0, 0

        if timestamp is None:
            timestamp = time.time()

        # 这一段和普通鼠标模式共享同一套自适应输入准备逻辑：
        # 先学习中心偏差与动态死区，再做归一化、稳态锁和输出压缩。
        self._update_adaptive_state(yaw, pitch, timestamp)
        compensated_yaw = yaw - self.pose_bias_x
        compensated_pitch = pitch - self.pose_bias_y

        if self.adaptive_learning:
            adaptive_yaw = self._normalize_adaptive_pose(
                compensated_yaw,
                self.learned_range_left,
                self.learned_range_right,
                self.current_deadzone_x,
            )
            adaptive_pitch = self._normalize_adaptive_pose(
                compensated_pitch,
                self.learned_range_up,
                self.learned_range_down,
                self.current_deadzone_y,
            )
        else:
            adaptive_yaw = self.apply_soft_deadzone(compensated_yaw)
            adaptive_pitch = self.apply_soft_deadzone(compensated_pitch)

        adaptive_yaw, self.output_lock_x = self._apply_output_lock(adaptive_yaw, self.output_lock_x)
        adaptive_pitch, self.output_lock_y = self._apply_output_lock(adaptive_pitch, self.output_lock_y)

        # 这里单独保留一份“压缩前的垂直控制量”给滚轮使用。
        # 原因是：
        # 普通鼠标移动需要把中心区域压得更细，方便停点；
        # 但滚轮如果也复用这层垂直压缩，抬头 / 低头信号会被压得太小，
        # 后面再叠加滚轮专用死区后，就很可能完全过不了阈值。
        scroll_control_pitch = adaptive_pitch

        adaptive_yaw = self._compress_adaptive_output(adaptive_yaw, self.adaptive_output_gain_x)

        if self.output_lock_x and self.output_lock_y:
            self.reset_motion()
            return 0, 0

        # 滚轮模式下仍然允许水平鼠标移动，但垂直像素位移被固定成 0，
        # 这样低头 / 抬头只负责滚页，不再把光标往上往下推走。
        shaped_yaw = self.shape_input(adaptive_yaw)
        raw_dx = shaped_yaw * self.sensitivity_x
        smooth_dx, _ = self.motion_smoother.smooth(raw_dx, 0.0, timestamp)
        move_x = self.clamp(smooth_dx, -self.max_step, self.max_step)

        send_x = 0
        if abs(move_x) >= 0.05:
            self.remainder_x += move_x
            send_x = int(round(self.remainder_x))
            self.remainder_x -= send_x
            if send_x != 0:
                self._safe_move_rel(send_x, 0)

        # 滚轮故意不吃“鼠标专用的垂直压缩后结果”，
        # 而是直接吃压缩前、但已经过稳态锁的垂直控制量。
        # 这样既保留了中性位稳定性，又不会把点头信号压到几乎出不来。
        scroll_steps = self._emit_scroll(scroll_control_pitch, timestamp)
        return send_x, scroll_steps

    def handle_eye_gestures(
        self,
        left_eye_closed: bool,
        right_eye_closed: bool,
        timestamp: Optional[float] = None,
    ) -> Optional[str]:
        """根据左右眼闭合状态触发左击、右击和双击。"""
        if timestamp is None:
            timestamp = time.time()

        if not self.enabled:
            self.eye_state_text = "Controller disabled"
            return None

        if left_eye_closed and right_eye_closed:
            # 双眼闭合优先级最高，会覆盖单眼点击分支。
            self.eye_state_text = "Both eyes closed"
            self.left_only_since = None
            self.right_only_since = None
            self.left_click_sent = False
            self.right_click_sent = False

            if self.both_closed_since is None:
                self.both_closed_since = timestamp
                return None

            hold_duration = timestamp - self.both_closed_since
            if not self.double_click_sent and hold_duration >= self.double_click_hold:
                self._safe_click(button="left", clicks=2)
                self.double_click_sent = True
                self.wait_for_full_open = True
                return self._remember_action("Double left click", timestamp)

            return None

        self.both_closed_since = None

        if self.wait_for_full_open:
            # 双击后强制等到双眼完全睁开，避免还没睁眼就再次连续触发。
            if not left_eye_closed and not right_eye_closed:
                self.wait_for_full_open = False
                self.double_click_sent = False
                self.left_click_sent = False
                self.right_click_sent = False
                self.left_only_since = None
                self.right_only_since = None
                self.eye_state_text = "Both eyes open"
            else:
                self.eye_state_text = "Waiting eyes reopen"
            return None

        if left_eye_closed and not right_eye_closed:
            # 左眼单闭合链路：计时达到阈值后发左键单击。
            self.eye_state_text = "Left eye closed"
            self.right_only_since = None
            self.right_click_sent = False

            if self.left_only_since is None:
                self.left_only_since = timestamp
                return None

            if not self.left_click_sent and (timestamp - self.left_only_since) >= self.single_eye_closed_hold_time:
                self._safe_click(button="left", clicks=1)
                self.left_click_sent = True
                return self._remember_action("Left click", timestamp)

            return None

        if right_eye_closed and not left_eye_closed:
            # 右眼单闭合链路：与左眼分支对称，只是最终发右键单击。
            self.eye_state_text = "Right eye closed"
            self.left_only_since = None
            self.left_click_sent = False

            if self.right_only_since is None:
                self.right_only_since = timestamp
                return None

            if not self.right_click_sent and (timestamp - self.right_only_since) >= self.single_eye_closed_hold_time:
                self._safe_click(button="right", clicks=1)
                self.right_click_sent = True
                return self._remember_action("Right click", timestamp)

            return None

        self.eye_state_text = "Both eyes open"
        self.left_only_since = None
        self.right_only_since = None
        self.left_click_sent = False
        self.right_click_sent = False
        self.double_click_sent = False
        return None

    # 把当前眼部状态和最近动作整理成一行给界面显示。
    def get_debug_text(self, timestamp: Optional[float] = None) -> str:
        """返回调试界面用的状态文本。"""
        if timestamp is None:
            timestamp = time.time()

        # edge_text:
        #     当鼠标正在左边界或右边界等待自动回中时，
        #     这里会显示当前还剩多少秒触发回中。
        edge_text = ""
        if self.left_edge_since is not None:
            remaining = max(0.0, self.left_edge_hold_seconds - (timestamp - self.left_edge_since))
            edge_text = f" | Left edge center in {remaining:.1f}s"
        elif self.right_edge_since is not None:
            remaining = max(0.0, self.left_edge_hold_seconds - (timestamp - self.right_edge_since))
            edge_text = f" | Right edge center in {remaining:.1f}s"

        # 调试界面里单独标出当前模式，方便你肉眼确认“现在到底是在鼠标模式还是滚轮模式”。
        mode_text = "Scroll" if self.scroll_mode_enabled else "Mouse"

        # 调试文本里额外显示自适应控制状态，方便边运行边观察:
        # - DZ: 当前动态死区
        # - BaseRange: 当前使用的固定控制范围
        adaptive_text = ""
        if self.adaptive_learning:
            adaptive_text = (
                " | DZ "
                f"{self.current_deadzone_x:.3f}/{self.current_deadzone_y:.3f}"
                " | BaseRange "
                f"L{self.learned_range_left:.3f} R{self.learned_range_right:.3f} "
                f"U{self.learned_range_up:.3f} D{self.learned_range_down:.3f}"
                " | Bias "
                f"{self.pose_bias_x:+.3f}/{self.pose_bias_y:+.3f}"
                " | Lock "
                f"{'Y' if self.output_lock_x else 'N'}{'Y' if self.output_lock_y else 'N'}"
            )

        if timestamp - self.last_action_timestamp <= 1.5:
            return f"Mode: {mode_text} | Eyes: {self.eye_state_text} | Last: {self.last_action_text}{edge_text}{adaptive_text}"

        if not self.enabled:
            return f"Mode: {mode_text} | Eyes: {self.eye_state_text} | Mouse disabled{edge_text}{adaptive_text}"

        return f"Mode: {mode_text} | Eyes: {self.eye_state_text}{edge_text}{adaptive_text}"
