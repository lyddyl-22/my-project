import statistics
import time
from dataclasses import dataclass
from typing import List, Optional

import cv2


@dataclass
class FocusCalibrationProfile:
    """
    一次注视校准结束后生成的结果对象。

    这份对象会被主流程同时交给两个模块：
    - `visual.py`：把新的 `center_yaw / center_pitch` 作为视觉中心姿态
    - `mouse_controller.py`：把推荐鼠标参数应用到实际控制器

    字段说明：
    - center_yaw / center_pitch：
        用户自然注视屏幕中心时，头部更接近的中性姿态。
    - recommended_deadzone：
        推荐的软死区大小。静止噪声越大，这个值通常越需要偏大。
    - recommended_sensitivity_x / recommended_sensitivity_y：
        推荐的水平、垂直灵敏度。
    - recommended_acceleration：
        推荐的非线性加速强度。
    - recommended_max_step：
        推荐的单帧最大位移上限。
    - stability：
        0 到 1 之间的稳定度评分，越高说明这次 10 秒采样越稳。
    - noise_yaw / noise_pitch：
        yaw 与 pitch 两个方向的噪声估计。
    - sample_count：
        实际参与统计的有效样本数。
    """

    # 中性头位估计结果，后续会同步给视觉模块作为中心姿态。
    center_yaw: float
    center_pitch: float
    # 以下 recommended_* 会同步给鼠标控制器作为推荐运行参数。
    recommended_deadzone: float
    recommended_sensitivity_x: float
    recommended_sensitivity_y: float
    recommended_acceleration: float
    recommended_max_step: float
    # stability 是 0~1 之间的稳定度评分，越高说明 10 秒采样越平稳。
    stability: float
    noise_yaw: float
    noise_pitch: float
    # sample_count 记录这次校准真正纳入统计的样本数量。
    sample_count: int


class FocusCalibrator:
    """
    屏幕中心注视校准器。

    这个模块并不做真正的眼球追踪。
    它依赖一个更务实的假设：
    当用户自然看向屏幕中心时，头部姿态通常也更接近自己的中性位置。

    这个类主要负责三件事：
    1. 管理“开始校准 -> 采样 -> 完成校准”的状态流转
    2. 根据 10 秒采样结果计算中心姿态与推荐鼠标参数
    3. 在画面上绘制准星、进度条和状态文字
    """

    # duration_seconds:
    #     需要累计多少秒“有效采样时间”。
    # min_samples:
    #     至少需要多少个有效样本，避免帧率过低时样本太少。
    # message_hold_seconds:
    #     校准完成提示在画面上额外停留多久。
    def __init__(self, duration_seconds: float = 10.0, min_samples: int = 50, message_hold_seconds: float = 3.0):
        """
        参数说明：
        - duration_seconds：
            需要积累多少秒“有效采样时间”。
            这里不是简单的墙钟时间，而是满足条件的有效帧时间总和。
        - min_samples：
            至少需要多少个有效样本点。
            这样即便帧率较低，也能避免样本太少导致结果不稳。
        - message_hold_seconds：
            校准完成后的提示信息保留多久。
        """
        self.duration_seconds = duration_seconds
        self.min_samples = min_samples
        self.message_hold_seconds = message_hold_seconds

        # `running`：
        #     当前是否正在校准。
        # `collected_seconds`：
        #     当前已经累计到的“有效采样秒数”。
        # `last_valid_timestamp`：
        #     最近一个有效采样帧的时间戳，用于计算下一帧应增加多少有效时长。
        self.running = False
        self.collected_seconds = 0.0
        self.last_valid_timestamp: Optional[float] = None

        # 采样保存的是“原始姿态”而不是扣过中心后的姿态。
        # 因为我们的目标就是重新估计一个新的中心值。
        self.raw_yaw_samples: List[float] = []
        self.raw_pitch_samples: List[float] = []

        # 这些基础参数来自校准开始那一刻的控制器默认配置。
        # 后续生成推荐参数时，会在它们的基础上做有限度调整。
        self.base_sensitivity_x = 0.0
        self.base_sensitivity_y = 0.0
        self.base_deadzone = 0.0
        self.base_max_step = 0.0
        self.base_acceleration = 0.0

        # 画面提示文字：
        # `live_status_text` 用于显示当前阶段状态；
        # `hold_message_text` 用于校准完成后的短暂停留提示；
        # `hold_message_until` 表示这条提示有效到什么时间。
        self.live_status_text = "Focus calibration will start automatically on launch"
        self.hold_message_text = ""
        self.hold_message_until = 0.0

        # 保存最近一轮校准结果，方便主流程之外的模块调试或复用。
        self.last_profile: Optional[FocusCalibrationProfile] = None

    @staticmethod
    # 通用限幅工具，避免评分和推荐参数跑出经验范围。
    def _clamp(value: float, min_value: float, max_value: float) -> float:
        """
        把数值限制在 `[min_value, max_value]` 范围内。

        这个小工具主要用来做两类保护：
        1. 避免时间增量、推荐参数等数值过大或过小
        2. 把一些经验性评分稳定在可控范围内
        """
        return max(min_value, min(max_value, value))

    @staticmethod
    # 用 MAD 估计噪声强度，比标准差更不容易被偶发跳点带偏。
    def _robust_noise(samples: List[float], center_value: float) -> float:
        """
        用 MAD（Median Absolute Deviation，中位数绝对偏差）估计噪声强度。

        为什么不用普通标准差：
        - 摄像头关键点有时会偶发跳一下
        - 标准差更容易被这种尖峰拉大
        - MAD 对离群点更不敏感，更适合实时视觉场景

        返回值是一个“该方向噪声大概有多强”的估计量。
        """
        if not samples:
            return 0.0

        absolute_deviations = [abs(sample - center_value) for sample in samples]
        mad = statistics.median(absolute_deviations)
        return mad * 1.4826

    # 开始一轮新的启动校准，同时记录这轮校准所对应的基础鼠标参数。
    def start(self, controller_profile: dict, timestamp: Optional[float] = None):
        """
        开始一轮新的注视校准。

        参数：
        - controller_profile：
            当前鼠标控制器给出的基础参数字典。
            这里通常来自 `mouse_controller.get_focus_base_profile()`。
        - timestamp：
            校准开始时间；如果不传，就使用当前系统时间。

        调用后会：
        1. 清空上一轮采样数据
        2. 记录当前这轮使用的基础鼠标参数
        3. 把状态切到 `running=True`
        4. 更新画面提示文字
        """
        if timestamp is None:
            timestamp = time.time()

        self.running = True
        self.collected_seconds = 0.0
        self.last_valid_timestamp = None
        self.raw_yaw_samples.clear()
        self.raw_pitch_samples.clear()

        self.base_sensitivity_x = controller_profile["sensitivity_x"]
        self.base_sensitivity_y = controller_profile["sensitivity_y"]
        self.base_deadzone = controller_profile["deadzone"]
        self.base_max_step = controller_profile["max_step"]
        self.base_acceleration = controller_profile["acceleration"]

        self.live_status_text = "Focus calibration started. Look at the screen center."
        self.hold_message_text = "Focus calibration started"
        self.hold_message_until = timestamp + 1.0

    # 根据累计样本生成最终校准结果，包括中心姿态、噪声估计和推荐鼠标参数。
    def _build_profile(self) -> FocusCalibrationProfile:
        """
        根据当前累计样本生成一份校准结果。

        主要步骤：
        1. 用中位数估计新的中心头位
        2. 用 MAD 估计两个方向的噪声
        3. 依据噪声大小计算稳定度评分
        4. 再把稳定度映射成一组更合适的鼠标参数建议

        这些推荐参数不是随意拍脑袋生成的，
        而是在“当前默认参数”的基础上做有限范围内的小幅调整。
        """
        # 中位数比均值更不容易被偶发离群值拉偏，
        # 所以更适合拿来做中心姿态估计。
        center_yaw = statistics.median(self.raw_yaw_samples)
        center_pitch = statistics.median(self.raw_pitch_samples)

        noise_yaw = self._robust_noise(self.raw_yaw_samples, center_yaw)
        noise_pitch = self._robust_noise(self.raw_pitch_samples, center_pitch)

        # 当前把两个方向里更大的噪声作为总体噪声参考。
        # 因为任意一个方向明显不稳，都会影响整体体验。
        noise_level = max(noise_yaw, noise_pitch)

        # 把噪声粗略映射成 0~1 的稳定度评分：
        # - 越接近 1：说明更稳
        # - 越接近 0：说明噪声更大
        stability = self._clamp(1.0 - noise_level / 0.03, 0.0, 1.0)

        # 噪声越大，死区应该适当放大。
        # 否则用户不动时，细小噪声也会更容易推动鼠标。
        # 校准后的 deadzone 只允许维持或变大，不再主动缩小。
        # 这样可以避免“校准完成后比校准前更敏感”的反直觉手感。
        # `noise_level * 3.8` 的作用可以理解为:
        #     把 10 秒采样里观测到的自然抖动，换算成一个更安全的控制缓冲区。
        #     抖动越明显，这个缓冲区就越大。
        recommended_deadzone = self._clamp(
            self.base_deadzone + noise_level * 3.8,
            self.base_deadzone,
            0.045,
        )

        # 横向、纵向灵敏度分别根据各自方向噪声来缩放。
        # 某个方向越抖，就越保守一点。
        # 启动校准后的灵敏度只做“保守修正”，不再把速度往上推。
        # 这样校准完成后，手感最多和原来一样，或者更稳，不会突然变快。
        # 这里把上限钳在 1.00，意思是:
        #     校准模块最多认为“当前基础灵敏度已经合适”，不会再推荐更激进的速度。
        sensitivity_scale_x = self._clamp(0.96 - noise_yaw * 8.0, 0.72, 1.00)
        sensitivity_scale_y = self._clamp(0.96 - noise_pitch * 8.0, 0.72, 1.00)
        recommended_sensitivity_x = self.base_sensitivity_x * sensitivity_scale_x
        recommended_sensitivity_y = self.base_sensitivity_y * sensitivity_scale_y

        # 加速和最大步长同样改为“只保守、不激进”。
        # 启动校准的目标是提升可控性，不是让控制器更冲。
        # stability 越高，只表示“可以少收一点”，而不是“可以往上加速”。
        recommended_acceleration = self._clamp(
            self.base_acceleration * (0.82 + stability * 0.10),
            1.0,
            self.base_acceleration,
        )
        recommended_max_step = self._clamp(
            self.base_max_step * (0.82 + stability * 0.10),
            self.base_max_step * 0.70,
            self.base_max_step,
        )

        return FocusCalibrationProfile(
            center_yaw=center_yaw,
            center_pitch=center_pitch,
            recommended_deadzone=recommended_deadzone,
            recommended_sensitivity_x=recommended_sensitivity_x,
            recommended_sensitivity_y=recommended_sensitivity_y,
            recommended_acceleration=recommended_acceleration,
            recommended_max_step=recommended_max_step,
            stability=stability,
            noise_yaw=noise_yaw,
            noise_pitch=noise_pitch,
            sample_count=len(self.raw_yaw_samples),
        )

    # 每处理一帧就推进一次校准状态机。
    # 只有“检测到脸且双眼都睁开”的帧才会计入有效采样。
    def update(self, analysis, timestamp: Optional[float] = None) -> Optional[FocusCalibrationProfile]:
        """
        推进当前这轮校准。

        参数：
        - analysis：
            当前帧视觉分析结果。如果当前帧没有检测到脸，可传 `None`。
        - timestamp：
            当前帧时间戳。

        一帧要想算作“有效采样”，必须同时满足：
        1. 当前检测到了脸
        2. 左右眼都保持睁开

        返回值：
        - 未完成时返回 `None`
        - 如果这一帧刚好完成校准，则返回新的 `FocusCalibrationProfile`
        """
        if timestamp is None:
            timestamp = time.time()

        # 没在运行中的话，直接忽略 update 调用。
        if not self.running:
            return None

        # 没检测到脸时，这一帧不计入有效采样，
        # 同时把“上一帧有效时间戳”清掉，防止下次恢复时 dt 突然很大。
        if analysis is None:
            self.live_status_text = "Focus calibration paused: no face detected"
            self.last_valid_timestamp = None
            return None

        # 如果有单眼或双眼闭合，也暂停采样。
        # 因为闭眼动作通常伴随额外面部变化，不适合作为稳定中心样本。
        if analysis.left_eye_closed or analysis.right_eye_closed:
            self.live_status_text = "Focus calibration paused: keep both eyes open"
            self.last_valid_timestamp = None
            return None

        # 第一帧有效样本只负责记住“从哪一刻开始”，
        # 不会立刻给 collected_seconds 加时长。
        if self.last_valid_timestamp is None:
            self.last_valid_timestamp = timestamp
        else:
            # dt 只累计相邻两次有效帧的间隔。
            # 这里给了 0.2 秒上限，是为了防止偶发卡顿时一次加太多。
            dt = self._clamp(timestamp - self.last_valid_timestamp, 0.0, 0.2)
            self.collected_seconds += dt
            self.last_valid_timestamp = timestamp

        # 把当前帧的原始姿态加入样本池。
        self.raw_yaw_samples.append(analysis.raw_yaw)
        self.raw_pitch_samples.append(analysis.raw_pitch)

        remaining_seconds = max(0.0, self.duration_seconds - self.collected_seconds)
        self.live_status_text = f"Focus calibration: keep looking at the center ({remaining_seconds:.1f}s left)"

        # 同时满足“有效时长足够”和“样本数量足够”才算真正完成。
        if self.collected_seconds >= self.duration_seconds and len(self.raw_yaw_samples) >= self.min_samples:
            profile = self._build_profile()
            self.running = False
            self.last_valid_timestamp = None
            self.last_profile = profile

            # 完成后短暂显示一条结果摘要，方便用户观察这次校准效果。
            self.hold_message_text = (
                f"Focus calibration applied | stability {profile.stability:.2f} | "
                f"deadzone {profile.recommended_deadzone:.4f}"
            )
            self.hold_message_until = timestamp + self.message_hold_seconds
            self.live_status_text = "Startup focus calibration completed"
            return profile

        return None

    # 负责绘制校准阶段的准星、进度条和顶部状态文字。
    def draw_overlay(self, frame, timestamp: Optional[float] = None):
        """
        在画面上绘制校准辅助界面。

        当前绘制内容分两类：
        - 校准进行中：
            画中心准星、进度条、底部提示文字
        - 校准结束后：
            先短暂显示结果摘要，然后显示默认完成提示
        """
        if timestamp is None:
            timestamp = time.time()

        frame_h, frame_w = frame.shape[:2]
        center_x = frame_w // 2
        center_y = frame_h // 2

        if self.running:
            # 中心准星的颜色统一用黄色，提醒用户“正在对准中心”。
            color = (0, 255, 255)
            arm = 28
            gap = 10
            radius = 18

            # 中间圆环和十字臂只负责提供视觉参考，不参与任何算法计算。
            cv2.circle(frame, (center_x, center_y), radius, color, 2)
            cv2.line(frame, (center_x - arm, center_y), (center_x - gap, center_y), color, 2)
            cv2.line(frame, (center_x + gap, center_y), (center_x + arm, center_y), color, 2)
            cv2.line(frame, (center_x, center_y - arm), (center_x, center_y - gap), color, 2)
            cv2.line(frame, (center_x, center_y + gap), (center_x, center_y + arm), color, 2)

            # 进度条反映的是“有效采样时间比例”，而不是总运行时间。
            progress_ratio = self._clamp(self.collected_seconds / self.duration_seconds, 0.0, 1.0)
            bar_width = min(360, frame_w - 60)
            bar_height = 18
            bar_x = (frame_w - bar_width) // 2
            bar_y = frame_h - 55

            cv2.rectangle(frame, (bar_x, bar_y), (bar_x + bar_width, bar_y + bar_height), (80, 80, 80), 2)
            cv2.rectangle(
                frame,
                (bar_x + 2, bar_y + 2),
                (bar_x + int((bar_width - 4) * progress_ratio), bar_y + bar_height - 2),
                (0, 200, 255),
                -1,
            )

        # 顶部文字分三种状态：
        # 1. 运行中：显示实时倒计时状态
        # 2. 刚完成：显示短暂停留结果摘要
        # 3. 其他：显示默认完成提示
        if self.running:
            top_text = self.live_status_text
            top_color = (0, 255, 255)
        elif timestamp <= self.hold_message_until and self.hold_message_text:
            top_text = self.hold_message_text
            top_color = (0, 255, 0)
        else:
            top_text = "Startup focus calibration completed"
            top_color = (255, 255, 255)

        cv2.putText(
            frame,
            top_text,
            (20, frame_h - 85 if self.running else 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            top_color,
            2,
        )

        return frame

    # 把当前校准状态整理成一行字符串，供其他模块复用。
    def get_status_text(self, timestamp: Optional[float] = None) -> str:
        """
        返回当前校准状态文本。

        这个方法不负责画图，只负责把“现在应该显示什么文字”统一封装出来，
        方便其他模块在有需要时复用。
        """
        if timestamp is None:
            timestamp = time.time()

        if self.running:
            return self.live_status_text

        if timestamp <= self.hold_message_until and self.hold_message_text:
            return self.hold_message_text

        return "Startup focus calibration completed"
