import time

import cv2

from foucus import FocusCalibrator
from mouse_controller import HeadMouseController
from visual import FaceAnalyzer, FaceResultBuffer, create_face_landmarker, draw_debug_info, make_mp_image


def main():
    """
    程序主入口。

    主流程很简单：
    1. 打开摄像头并异步做人脸关键点检测
    2. 把关键点转换成头部姿态和眼睛状态
    3. 启动时自动把光标放到屏幕中心，并开始 10 秒中心注视校准
    4. 校准结束后用头部姿态控制鼠标，用闭眼触发点击
    """

    # OpenCV 显示窗口的名字。
    # 之所以单独提成变量，是因为后面 `imshow()`、窗口关闭检测都会复用它。
    window_name = "Head Mouse Control"

    # 打开默认摄像头。
    # `0` 一般表示系统里的第一个摄像头设备。
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Cannot open camera.")
        return

    # MediaPipe 在直播模式下是异步返回结果的，
    # 所以这里需要一个线程安全的缓冲区，把“最近一次检测结果”暂存起来。
    result_buffer = FaceResultBuffer()

    # 人脸分析器负责把原始关键点变成项目真正使用的控制信号。
    # 下面这些参数都会直接影响眼睛开闭识别和自动中心校准的稳定性。
    face_analyzer = FaceAnalyzer(
        # EAR 低于这个阈值时，开始判定为“眼睛闭合”。
        eye_closed_threshold=0.18,
        # 眼睛重新张开时，EAR 需要高于这个值才算“恢复睁眼”。
        # 它比闭眼阈值略高，形成滞回区，减少边界抖动。
        eye_reopen_threshold=0.21,
        # 闭眼或重新睁眼都不是单帧立刻切换，
        # 而是要求连续满足这么多帧，避免误判。
        eye_state_confirm_frames=3,
        # 启动初期自动估计中性头位时，最多保留多少帧作为样本窗口。
        calibration_frames=30,
        # 程序运行中允许中心姿态缓慢漂移修正的速度。
        # 值越大，中心越容易跟着用户长期习惯变化。
        center_drift_alpha=0.02,
        # 只有当前姿态已经接近中心时，才允许做上面的慢速修正。
        # 这样可以避免把用户主动大幅转头误吸收到中心值里。
        center_drift_limit=0.05,
        # 张嘴比例超过这个阈值时，开始朝“嘴巴张开”方向判定。
        # 它不是单帧立刻生效，而是会配合下面的连续帧确认一起使用。
        mouth_open_threshold=0.16,
        # 从“张嘴”回到“闭嘴”时使用更低一点的阈值，形成滞回区，减少嘴唇边缘抖动。
        mouth_close_threshold=0.12,
        # 张嘴 / 闭嘴都需要连续满足这么多帧，才正式切换口部状态。
        # 这样可以降低说话时短暂口型变化带来的误触。
        mouth_state_confirm_frames=3,
    )

    # 鼠标控制器负责把 `yaw / pitch` 映射成鼠标移动，
    # 同时还管理闭眼点击的状态机。
    mouse_controller = HeadMouseController(
        # 水平方向灵敏度。
        # 值越大，同样幅度的左右转头带来的鼠标横向移动越大。
        sensitivity_x=120.0,
        # 垂直方向灵敏度。
        # 值越大，同样幅度的抬头低头带来的鼠标纵向移动越大。
        sensitivity_y=90.0,
        # 软死区阈值。
        # 很小的自然抖动会在这里被吃掉，不会直接推动鼠标。
        deadzone=0.012,
        # 单帧最大位移限制，用来防止姿态突跳时鼠标一下飞太远。
        max_step=25.0,
        # 非线性加速强度。
        # 小动作仍然细腻，大动作会被放大得更积极。
        acceleration=1.8,
        # 左眼或右眼单独闭合达到这个持续时间后触发单击。
        single_eye_closed_hold_time=0.80,
        # 双眼同时闭合达到这个持续时间后触发双击。
        double_click_hold=0.80,
        # 滚轮模式使用更保守的专用死区，避免轻微低头 / 抬头就开始滚页。
        scroll_deadzone=0.06,
        # 满量程点头时的滚轮速度标尺，值越大滚得越快。
        # 这里保持中等偏保守，先确保能稳定触发，再避免一下滚太猛。
        scroll_sensitivity=26.0,
        # 单帧最大滚轮步数上限，避免某一帧突然滚过头。
        scroll_step_limit=4,
        # 两次张嘴切换之间的最短间隔，防止嘴巴边缘抖动连切两次。
        mouth_toggle_cooldown=0.80,
        # 切到滚轮模式后先留一点缓冲时间，避免切模式动作本身立刻触发滚动。
        scroll_toggle_settle_seconds=0.25,
        # 启动时默认开启头控鼠标。
        enabled=True,
    )

    # 注视校准器会在启动后自动采样一段时间，
    # 估计用户自然看向屏幕中心时的中性头位，并给出一组推荐鼠标参数。
    focus_calibrator = FocusCalibrator(
        # 需要累积多少秒“有效样本时间”。
        # 注意这里不是单纯的墙钟时间，而是检测到脸且双眼睁开的有效时长。
        duration_seconds=10.0,
        # 至少需要多少个有效样本点，防止帧率太低时样本不足。
        min_samples=50,
        # 校准完成后的提示信息在画面上保留多久。
        message_hold_seconds=3.0,
    )

    # 记录启动时刻，后面初始化动作都统一基于这个时间点。
    startup_timestamp = time.time()

    # 启动时先把光标放到屏幕中央。
    # 这样可以避免光标一开始就在左上角触发 fail-safe，
    # 也能让用户在自动校准阶段有更稳定的初始状态。
    mouse_controller.center_cursor(startup_timestamp)

    # 清空上一轮可能残留的运动和平滑历史，确保启动阶段是干净状态。
    mouse_controller.reset_motion()
    mouse_controller.reset_eye_gesture_state(no_face=False)

    # 启动后立刻开始自动中心校准。
    # 这里传入的是控制器的“基础参数快照”，
    # 不是已经被校准改写后的实时参数。
    focus_calibrator.start(
        mouse_controller.get_focus_base_profile(),
        startup_timestamp,
    )

    # 显式创建窗口，方便后面通过窗口属性判断是否被用户点叉关闭。
    cv2.namedWindow(window_name)

    try:
        # 用 `with` 管理 MediaPipe 检测器的生命周期，退出时自动释放资源。
        with create_face_landmarker(result_buffer.save_result) as landmarker:
            while True:
                # 读取摄像头当前一帧。
                ret, frame = cap.read()
                if not ret:
                    print("Failed to read camera frame.")
                    break

                # 左右镜像翻转，保证用户看到的自己和动作方向更符合直觉。
                frame = cv2.flip(frame, 1)
                frame_h, frame_w = frame.shape[:2]

                # 当前帧统一使用同一个时间戳，避免不同模块基于不同时间计算。
                timestamp = time.time()

                # 每一帧都检查一次“左边界停留自动回中”。
                # 这样即使当前正在校准，或者暂时没检测到脸，只要鼠标卡在左边界，
                # 连续停留 5 秒后也会自动回到屏幕中心。
                # 检查鼠标是否持续贴在左右边界，满 5 秒后自动回到屏幕中心。
                mouse_controller.monitor_left_edge_recenter(timestamp)

                # 把 OpenCV 的 BGR 帧转换成 MediaPipe 支持的图像格式，
                # 然后异步送进人脸关键点检测器。
                mp_image = make_mp_image(frame)
                landmarker.detect_async(mp_image, int(timestamp * 1000))

                # `display` 是专门用于绘制调试信息的画面副本，
                # 不直接改原始帧，便于保持处理逻辑清晰。
                display = frame.copy()

                # 取出当前为止检测器给回来的“最新结果”。
                # 因为检测是异步的，所以它可能来自稍早一点的某一帧。
                latest_result = result_buffer.get_latest_result()

                if latest_result is not None and latest_result.face_landmarks:
                    # 当前项目只处理第一张脸，因为默认只有一个主使用者。
                    face_landmarks = latest_result.face_landmarks[0]

                    # 把原始关键点转换成头部姿态、EAR、闭眼状态等高层结果。
                    analysis = face_analyzer.analyze(face_landmarks, frame_w, frame_h)

                    # 每一帧都尝试推进自动注视校准。
                    # 如果刚好在这一帧满足完成条件，就会返回一份新的校准结果。
                    focus_profile = focus_calibrator.update(analysis, timestamp)
                    if focus_profile is not None:
                        # 先更新视觉模块里的中心姿态，
                        # 让后续计算出来的 yaw / pitch 都围绕新的中心展开。
                        face_analyzer.apply_focus_center(
                            focus_profile.center_yaw,
                            focus_profile.center_pitch,
                        )
                        # 再把推荐鼠标参数应用到控制器。
                        mouse_controller.apply_focus_calibration(focus_profile, timestamp)

                    if focus_calibrator.running:
                        # 校准进行中时，不允许鼠标移动或点击，
                        # 否则光标会乱跑，也会把采样姿态扰乱。
                        mouse_controller.reset_motion()
                        mouse_controller.reset_eye_gesture_state(no_face=False)
                    else:
                        # 正常运行阶段：
                        # 1. 先根据“稳定后的张嘴状态”切换当前模式
                        # 2. 鼠标模式下: yaw / pitch 正常控制鼠标
                        # 3. 滚轮模式下: yaw 保留横向鼠标，pitch 改成页面滚轮
                        # 4. 眼睛闭合点击依旧保持可用
                        mouse_controller.handle_mouth_toggle(analysis.mouth_open, timestamp)
                        if mouse_controller.scroll_mode_enabled:
                            mouse_controller.update_scroll_mode(analysis.yaw, analysis.pitch, timestamp)
                        else:
                            mouse_controller.update(analysis.yaw, analysis.pitch, timestamp)
                        mouse_controller.handle_eye_gestures(
                            analysis.left_eye_closed,
                            analysis.right_eye_closed,
                            timestamp,
                        )

                    # 把关键点、EAR、姿态、最近动作等调试信息画到画面上。
                    display = draw_debug_info(
                        display,
                        analysis,
                        mouse_controller.get_debug_text(timestamp),
                    )

                    # 额外显示一个“当前已检测到人脸”的状态提示。
                    cv2.putText(
                        display,
                        "Face detected",
                        (20, frame_h - 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),
                        2,
                    )
                else:
                    # 没检测到脸时，这一帧不能计入校准采样。
                    focus_calibrator.update(None, timestamp)

                    # 同时清空鼠标移动和平滑历史，防止人脸重新出现后继承旧状态。
                    mouse_controller.handle_no_face()

                    cv2.putText(
                        display,
                        "No face",
                        (20, 40),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.8,
                        (0, 0, 255),
                        2,
                    )
                    # 即使没检测到脸，也把控制器当前状态显示出来，
                    # 方便观察是不是因为 fail-safe 被禁用了。
                    cv2.putText(
                        display,
                        mouse_controller.get_debug_text(timestamp),
                        (20, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 255),
                        2,
                    )

                # 最后统一绘制校准层，保证准星和进度条在最上层。
                display = focus_calibrator.draw_overlay(display, timestamp)

                # 底部固定帮助文字。
                cv2.putText(
                    display,
                    "Startup focus calibration runs automatically | Open mouth to toggle scroll mode | Hold at left/right edge 5s to center | Close window to quit",
                    (20, frame_h - 20),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (255, 255, 255),
                    2,
                )

                # 刷新窗口显示。
                cv2.imshow(window_name, display)

                # 读取键盘输入。
                # `waitKey(1)` 也是 OpenCV 窗口事件循环能够继续刷新的关键一步。
                key = cv2.waitKey(1) & 0xFF

                try:
                    # 如果用户直接点了窗口右上角的叉，
                    # 这里会检测到窗口不可见，然后退出主循环。
                    if cv2.getWindowProperty(window_name, cv2.WND_PROP_VISIBLE) < 1:
                        break
                except cv2.error:
                    break

                # 如果之前因为 fail-safe 暂停了鼠标控制，
                # 按 `e` 可以手动重新启用。
                if key == ord("e"):
                    mouse_controller.reenable(time.time())
    finally:
        # 无论正常结束还是异常结束，都尽量释放摄像头并关闭所有窗口。
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
