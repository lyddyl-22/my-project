# 头部控制鼠标项目

这是一个基于 `MediaPipe Face Landmarker`、`OpenCV`、`PyAutoGUI` 和 `NumPy` 的头控鼠标项目。  
程序会通过摄像头读取人脸关键点，估计头部左右转动、抬头低头、眼睛闭合状态和嘴部开合状态，再把这些状态转换成鼠标移动、点击和滚轮控制。

当前版本已经整理成“启动即用”的流程：

- 启动程序后，鼠标会先自动移动到屏幕中心
- 程序会自动开始一次 10 秒启动校准
- 校准完成后自动进入头控鼠标模式
- 张嘴可以在“普通鼠标模式”和“滚轮模式”之间切换
- 鼠标停留在屏幕左边界或右边界 5 秒后会自动回到屏幕中心
- 关闭窗口右上角的叉即可退出程序

## 当前功能

- 实时读取摄像头画面并检测人脸关键点
- 使用头部 `yaw / pitch` 控制鼠标移动
- 左眼闭合保持触发左键单击
- 右眼闭合保持触发右键单击
- 双眼同时闭合保持触发左键双击
- 张嘴切换滚轮模式
- 滚轮模式下保留左右横向鼠标移动，抬头/低头改为向上/向下滚轮
- 启动时自动执行中心注视校准
- 运行中自动修正中心偏差和动态死区
- 左右边界停留 5 秒自动回中
- 调试画面显示姿态、眼部、嘴部、校准状态和控制器内部状态

## 当前控制策略

当前版本不是“完全固定参数”，也不是“运行中持续学习动作范围”的版本。

现在的自适应策略只保留两部分：

- 在线学习当前用户的中心偏差
- 在线学习当前环境下的动态死区

当前版本**不再在线学习动作范围**。  
这样做的目的是避免最近几秒的小动作或短时噪声把控制范围越学越小，导致鼠标越来越快、越来越飘、越来越难精确停点。

当前控制链路可以理解成：

1. `visual.py` 输出稳定后的 `yaw / pitch`
2. `mouse_controller.py` 在线补偿中心偏差
3. `mouse_controller.py` 在线估计动态死区
4. 使用固定控制范围做归一化
5. 归一化结果经过稳态锁、输出压缩、非线性整形和平滑
6. 最终转换成鼠标位移或滚轮事件

这套策略更偏向：

- 稳定
- 可控
- 方便精确停点

## 依赖环境

项目依赖：

- `mediapipe`
- `opencv-python`
- `numpy`
- `pyautogui`

安装依赖：

```bash
pip install -r requirements.txt
```

如果使用 Windows 的 `py` 启动器，也可以：

```bash
py -m pip install -r requirements.txt
```

## 运行前准备

运行前请确认：

1. 已经安装 Python
2. 已经安装 `requirements.txt` 中的依赖
3. 摄像头可以正常使用
4. 系统允许程序控制鼠标
5. `face_landmarker.task` 与 `main.py` 位于同一目录

如果 `face_landmarker.task` 缺失，程序无法创建人脸关键点检测器。

## 运行方式

推荐进入项目实际代码目录后运行：

```bash
cd D:\PythonProject\all
python main.py
```

如果使用 `py` 启动器：

```bash
cd D:\PythonProject\all
py main.py
```

如果使用虚拟环境，也可以直接调用解释器：

```bash
D:\PythonProject\.venv\Scripts\python.exe D:\PythonProject\all\main.py
```

## 启动后会发生什么

程序启动后的完整流程如下：

1. 打开摄像头
2. 创建显示窗口
3. 把鼠标放到屏幕中心
4. 自动开始一次 10 秒启动校准
5. 校准完成后应用推荐参数
6. 自动进入正常头控鼠标模式

校准期间不会真的驱动鼠标移动，这样可以避免采样阶段光标乱跑。

## 操作说明

### 普通鼠标模式

- 向左转头：鼠标向左移动
- 向右转头：鼠标向右移动
- 抬头：鼠标向上移动
- 低头：鼠标向下移动

### 滚轮模式

- 张嘴一次：切换到滚轮模式
- 再次张嘴：切回普通鼠标模式
- 滚轮模式下：
  - 左右转头仍然控制鼠标横向移动
  - 抬头触发向上滚轮
  - 低头触发向下滚轮

为了避免误触，滚轮模式还有两层保护：

- 张嘴切换有冷却时间
- 切换到滚轮模式后会先等待一个很短的稳定时间，再允许真正发送滚轮

如果你已经切到了滚轮模式，但感觉页面没有滚动，请先确认鼠标指针停在一个真正可滚动的窗口上，比如浏览器、文档或设置窗口。

### 眼部点击

- 左眼闭合并保持：左键单击
- 右眼闭合并保持：右键单击
- 双眼同时闭合并保持：左键双击

当前默认点击保持时间在 `main.py` 中设置为：

- `single_eye_closed_hold_time = 0.80`
- `double_click_hold = 0.80`

## 自动校准说明

程序启动后会自动开始一次中心注视校准，不需要手动触发。

校准时建议你：

1. 自然地看向屏幕中心
2. 尽量保持头部稳定
3. 尽量保持双眼睁开
4. 不要频繁转头或做大幅动作

校准过程中：

- 没检测到脸时，采样会暂停
- 双眼闭合时，采样也会暂停
- 校准阶段不会驱动鼠标移动

校准完成后，程序会自动：

- 更新视觉模块的中心姿态
- 生成并应用一组更保守的推荐鼠标参数

当前校准策略是偏保守的：

- `deadzone` 只会保持原值或变大
- `sensitivity` 不会被校准得比启动前更高
- `acceleration` 和 `max_step` 也不会被校准得更激进

这样做是为了避免“校准后突然变快、变飘”。

## 边界保护说明

当前版本使用的是“边界停留回中”保护，不是旧版那种一碰到角落就直接失效。

具体逻辑如下：

- 鼠标连续停留在左边界 5 秒：自动回到屏幕中心
- 鼠标连续停留在右边界 5 秒：自动回到屏幕中心

这样可以防止鼠标卡在边缘之后，用户很难重新把它拉回来。

## 当前默认参数

这些参数都在 `main.py` 里创建对象时初始化。

### 视觉与状态识别

`FaceAnalyzer(...)` 当前默认值：

- `eye_closed_threshold = 0.18`
- `eye_reopen_threshold = 0.21`
- `eye_state_confirm_frames = 3`
- `calibration_frames = 30`
- `center_drift_alpha = 0.02`
- `center_drift_limit = 0.05`
- `mouth_open_threshold = 0.16`
- `mouth_close_threshold = 0.12`
- `mouth_state_confirm_frames = 3`

### 鼠标控制

`HeadMouseController(...)` 当前默认值：

- `sensitivity_x = 90.0`
- `sensitivity_y = 70.0`
- `deadzone = 0.012`
- `max_step = 25.0`
- `acceleration = 1.5`
- `single_eye_closed_hold_time = 0.80`
- `double_click_hold = 0.80`
- `scroll_deadzone = 0.06`
- `scroll_sensitivity = 26.0`
- `scroll_step_limit = 4`
- `mouth_toggle_cooldown = 0.80`
- `scroll_toggle_settle_seconds = 0.25`
- `enabled = True`

### 启动校准

`FocusCalibrator(...)` 当前默认值：

- `duration_seconds = 10.0`
- `min_samples = 50`
- `message_hold_seconds = 3.0`

## 应该去哪里调参数

如果你需要调整手感，优先从 `main.py` 里创建对象时传入的参数开始。

### 1. 视觉识别参数

位置：`FaceAnalyzer(...)`

常用参数：

- `eye_closed_threshold`
- `eye_reopen_threshold`
- `eye_state_confirm_frames`
- `calibration_frames`
- `center_drift_alpha`
- `center_drift_limit`
- `mouth_open_threshold`
- `mouth_close_threshold`
- `mouth_state_confirm_frames`

### 2. 鼠标控制参数

位置：`HeadMouseController(...)`

常用参数：

- `sensitivity_x`
- `sensitivity_y`
- `deadzone`
- `max_step`
- `acceleration`
- `single_eye_closed_hold_time`
- `double_click_hold`
- `scroll_deadzone`
- `scroll_sensitivity`
- `scroll_step_limit`
- `mouth_toggle_cooldown`
- `scroll_toggle_settle_seconds`

### 3. 自动校准参数

位置：`FocusCalibrator(...)`

常用参数：

- `duration_seconds`
- `min_samples`
- `message_hold_seconds`

## 调试画面说明

运行时窗口里会显示一些调试信息，常见内容包括：

- `yaw`：当前水平头部偏移
- `pitch`：当前垂直头部偏移
- `L EAR / R EAR`：左右眼开合程度
- `Mouth`：当前嘴部开合比例与开闭状态
- `Calibration`：当前校准状态或校准进度
- `Eyes: ...`：当前眼部状态
- `Last: ...`：最近一次控制动作
- `Mode: Mouse / Scroll`：当前普通鼠标模式或滚轮模式

控制器调试文本里还会显示：

- `DZ`：当前动态死区
- `BaseRange`：当前使用的固定控制范围
- `Bias`：当前中心偏差补偿量
- `Lock`：当前双轴是否处于稳态锁定状态

这些信息很适合在调手感时观察：

- 如果 `DZ` 很小，说明当前控制会更灵敏
- 如果 `Bias` 在慢慢变化，说明控制器正在修正中心头位
- 如果 `Lock` 经常不是 `YY`，说明控制器经常认为你仍在移动

## 项目结构

- [main.py](/D:/PythonProject/all/main.py)：主程序入口，负责摄像头循环、窗口显示和模块串联
- [visual.py](/D:/PythonProject/all/visual.py)：人脸关键点转姿态、EAR 计算、嘴部开合检测和中心位维护
- [mouse_controller.py](/D:/PythonProject/all/mouse_controller.py)：头部姿态转鼠标位移、闭眼点击、张嘴切换滚轮和边界保护
- [smooth.py](/D:/PythonProject/all/smooth.py)：平滑滤波相关工具
- [foucus.py](/D:/PythonProject/all/foucus.py)：启动阶段自动中心校准与推荐参数生成
- [face_landmarker.task](/D:/PythonProject/all/face_landmarker.task)：MediaPipe 模型文件
- [requirements.txt](/D:/PythonProject/all/requirements.txt)：Python 依赖列表

## 常见问题

### 1. 没有检测到脸

可能原因：

- 摄像头没有成功打开
- 光线太暗
- 脸离摄像头太远
- 头部偏出画面太多

建议：

- 增强环境光
- 保持脸位于画面中间
- 调整摄像头角度和高度

### 2. 鼠标太快或太慢

优先调整：

- `sensitivity_x`
- `sensitivity_y`
- `acceleration`
- `max_step`

### 3. 鼠标还是有点飘

优先关注：

- `deadzone`
- `center_drift_alpha`
- `center_drift_limit`

如果你观察到学习后仍然有漂移，重点看调试画面里的：

- `DZ`
- `Bias`
- `Lock`

### 4. 点位还是不够好停

优先关注：

- `mouse_controller.py` 里的自适应输出压缩参数
- `mouse_controller.py` 里的输出锁参数

这两组参数比单纯调总灵敏度更适合处理“能动，但难停准”的问题。

### 5. 滚轮模式切换了但没滚动

先确认：

1. 调试文字里是否显示 `Mode: Scroll`
2. 鼠标指针是否停在一个真正可滚动的窗口上
3. 抬头/低头的幅度是否明显超过滚轮死区

如果滚轮太慢或太难触发，优先调：

- `scroll_deadzone`
- `scroll_sensitivity`
- `scroll_step_limit`

### 6. 控制器被禁用

可以先尝试：

1. 把鼠标移回画面中间区域
2. 回到程序窗口
3. 按 `e`

### 7. 程序无法启动

先检查：

1. Python 是否已经安装
2. 依赖是否安装成功
3. `face_landmarker.task` 是否存在
4. 摄像头是否被其他程序占用

## 说明

这个项目更适合学习、实验、调参与功能验证。

头控鼠标会明显依赖这些因素：

- 摄像头位置
- 光照环境
- 屏幕距离
- 用户坐姿
- 个人头部动作习惯

所以实际使用时，通常仍然需要根据自己的设备和环境微调 `main.py` 里的初始参数。

如果你准备继续调手感，建议按这个顺序做：

1. 先观察调试画面里的 `DZ / Bias / Lock / Mode`
2. 再调 `deadzone / sensitivity / max_step`
3. 最后再调滚轮参数或输出压缩参数
