import math
from typing import Optional, Tuple


class LowPassFilter:
    """
    最基础的一阶低通滤波器。

    它只做一件事：
    把“当前输入值”和“上一帧输出值”按一定比例混合，得到更平滑的结果。

    可以把它理解成：
    - 越相信当前值，结果越灵敏，但也越容易抖
    - 越相信历史值，结果越稳定，但也越容易拖沓

    这个类本身不直接处理鼠标或人脸业务，
    主要作为 One Euro Filter 的底层构件使用。
    """

    # 这个类只负责“给一个标量做一次低通混合”，是更复杂滤波器的基础积木。
    def __init__(self):
        """
        初始化滤波器内部状态。

        `initialized`：
            表示滤波器是否已经收到过第一帧有效输入。
            第一帧没有历史值可以参考，因此会直接原样输出。

        `last_value`：
            记录上一帧滤波后的输出值。
            下一帧会用它和当前输入一起计算新的结果。
        """
        self.initialized = False
        self.last_value = 0.0

    # 清空上一轮历史，让下一次 filter 把输入当成新的起点。
    def reset(self):
        """
        清空滤波器历史。

        适用场景：
        - 人脸暂时消失
        - 切换控制模式
        - 应用新的校准结果

        这么做的目的，是防止旧历史把新一轮输入“拖住”。
        """
        self.initialized = False
        self.last_value = 0.0

    # value 是当前输入，alpha 是当前这一步混合时对新值的信任程度。
    def filter(self, value: float, alpha: float) -> float:
        """
        对一个标量做一次低通滤波。

        参数：
        - value：
            当前这一步的新输入值。
        - alpha：
            当前这一步使用的滤波系数，通常位于 0 到 1 之间。

        alpha 的含义：
        - 越接近 1：越偏向当前值，响应更快
        - 越接近 0：越偏向历史值，输出更稳

        返回值：
        - 当前这一步滤波后的输出值
        """
        # 第一次输入没有历史值可以混合，直接输出本帧值。
        if not self.initialized:
            self.initialized = True
            self.last_value = value
            return value

        # 标准一阶低通公式：
        # 新输出 = alpha * 当前输入 + (1 - alpha) * 上次输出
        self.last_value = alpha * value + (1.0 - alpha) * self.last_value
        return self.last_value


class OneEuroFilter:
    """
    One Euro Filter，自适应实时滤波器。

    这个滤波器特别适合“实时交互输入”：
    - 用户静止时，希望结果尽量稳，不要抖
    - 用户快速动作时，希望结果尽量跟手，不要拖

    它的核心想法不是“永远固定强度地平滑”，
    而是根据当前信号变化速度动态调整平滑强度：
    - 变化慢：加强平滑
    - 变化快：减弱平滑
    """

    # min_cutoff / beta / d_cutoff 共同决定“静止时多稳、快速动作时多跟手”。
    def __init__(self, min_cutoff: float = 1.2, beta: float = 0.25, d_cutoff: float = 1.0):
        """
        参数说明：
        - min_cutoff：
            基础截止频率。
            当输入几乎不动时，就以它作为默认“跟随速度”。
            值越大，静止时也会更灵敏；值越小，静止时会更稳。

        - beta：
            自适应增益。
            它决定“当检测到变化速度变快时，要把截止频率额外提高多少”。
            值越大，快速动作时越跟手。

        - d_cutoff：
            导数信号的截止频率。
            因为变化速度本身也会抖，所以先要把“速度估计”也平滑一下。
        """
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff

        # 一个滤波器负责平滑原始信号本身。
        self.signal_filter = LowPassFilter()
        # 另一个滤波器负责平滑“速度估计”。
        self.derivative_filter = LowPassFilter()

        # 保存上一帧时间戳和上一帧原始值，
        # 用来计算当前这一帧的变化速度。
        self.last_timestamp: Optional[float] = None
        self.last_raw_value: Optional[float] = None

    @staticmethod
    # 按截止频率和采样间隔把“滤波强度”换算成实际混合系数 alpha。
    def _alpha(cutoff: float, dt: float) -> float:
        """
        根据截止频率和采样间隔计算滤波系数 alpha。

        参数：
        - cutoff：
            当前这一步使用的截止频率。
            截止频率越大，滤波器越容易跟随输入变化。
        - dt：
            距离上一帧的时间间隔，单位是秒。

        返回值：
        - 对应这一步应该使用的 alpha
        """
        tau = 1.0 / (2.0 * math.pi * cutoff)
        return 1.0 / (1.0 + tau / dt)

    # One Euro Filter 内部维护了原始信号和平滑导数两套历史，这里统一清空。
    def reset(self):
        """
        重置整个 One Euro Filter 的内部历史。

        由于这个滤波器内部其实维护了两套低通滤波器，
        所以这里会把原始信号和平滑后的导数历史都一起清掉。
        """
        self.signal_filter.reset()
        self.derivative_filter.reset()
        self.last_timestamp = None
        self.last_raw_value = None

    # 核心步骤：
    # 1. 估计当前变化速度
    # 2. 先平滑速度估计
    # 3. 根据速度动态调整截止频率
    # 4. 用动态截止频率平滑原始输入
    def filter(self, value: float, timestamp: float) -> float:
        """
        对一个标量做 One Euro 平滑。

        输入参数：
        - value：
            当前帧原始输入值。
        - timestamp：
            当前帧时间戳，单位是秒。

        内部步骤：
        1. 用当前值和上一帧值估计“变化速度”
        2. 先对速度做平滑，得到更稳的速度估计
        3. 用速度估计决定当前应该使用多大的截止频率
        4. 再用这个自适应截止频率去平滑原始输入
        """
        # 第一次调用时没有上一帧，直接把当前值作为初始输出。
        if self.last_timestamp is None:
            self.last_timestamp = timestamp
            self.last_raw_value = value
            return self.signal_filter.filter(value, 1.0)

        # dt 至少给一个极小值，防止除零。
        dt = max(timestamp - self.last_timestamp, 1e-6)

        # 用“当前原始值 - 上一帧原始值”除以 dt，估计变化速度。
        if self.last_raw_value is None:
            raw_derivative = 0.0
        else:
            raw_derivative = (value - self.last_raw_value) / dt

        # 先平滑速度本身，避免因为速度估计过抖导致 alpha 也忽大忽小。
        derivative_alpha = self._alpha(self.d_cutoff, dt)
        derivative_hat = self.derivative_filter.filter(raw_derivative, derivative_alpha)

        # 当前实际使用的截止频率 = 基础截止频率 + 速度相关增量。
        # 速度越大，adaptive_cutoff 越大，也就越跟手。
        adaptive_cutoff = self.min_cutoff + self.beta * abs(derivative_hat)

        # 把当前步的截止频率换算成 signal_filter 所需的 alpha。
        signal_alpha = self._alpha(adaptive_cutoff, dt)

        # 用自适应出来的 alpha 对原始信号做平滑。
        filtered_value = self.signal_filter.filter(value, signal_alpha)

        # 更新历史，供下一帧继续使用。
        self.last_timestamp = timestamp
        self.last_raw_value = value
        return filtered_value


class AdaptiveMotionSmoother:
    """
    二维运动平滑器。

    它专门处理 `(x, y)` 这样的二维位移。
    内部做法很直接：
    - x 方向交给一个 One Euro Filter
    - y 方向交给另一个 One Euro Filter

    除此之外，它还额外加入了“静止阻尼”逻辑：
    当 x 和 y 都很小，说明用户大概率没有想真正移动，
    这时再额外压一层残余抖动，进一步减少静止漂移。
    """

    # 这是二维位移版平滑器，内部本质上是两个独立的一维 One Euro Filter。
    def __init__(
        self,
        min_cutoff: float = 1.2,
        beta: float = 0.25,
        d_cutoff: float = 1.0,
        idle_threshold: float = 1.2,
        idle_damping: float = 0.45,
    ):
        """
        参数说明：
        - min_cutoff / beta / d_cutoff：
            直接传给 x 和 y 两个 One Euro Filter。
        - idle_threshold：
            当输入位移绝对值低于这个阈值时，
            认为当前已经接近静止状态。
        - idle_damping：
            静止时额外乘上的阻尼系数。
            值越小，静止时压抖越强。
        """
        self.x_filter = OneEuroFilter(min_cutoff=min_cutoff, beta=beta, d_cutoff=d_cutoff)
        self.y_filter = OneEuroFilter(min_cutoff=min_cutoff, beta=beta, d_cutoff=d_cutoff)
        self.idle_threshold = idle_threshold
        self.idle_damping = idle_damping

    # 同时清空 x / y 两个方向的滤波历史。
    def reset(self):
        """
        同时清空 x 和 y 方向的平滑历史。
        """
        self.x_filter.reset()
        self.y_filter.reset()

    # 对二维位移做平滑，并在接近静止时额外压一层残余抖动。
    def smooth(self, x: float, y: float, timestamp: float) -> Tuple[float, float]:
        """
        对二维位移做平滑。

        参数：
        - x：当前帧 x 方向原始位移
        - y：当前帧 y 方向原始位移
        - timestamp：当前帧时间戳

        返回值：
        - 平滑后的 `(x, y)` 位移
        """
        # 先分别平滑两个方向。
        filtered_x = self.x_filter.filter(x, timestamp)
        filtered_y = self.y_filter.filter(y, timestamp)

        # 如果输入本来就已经很小，说明更接近静止状态，
        # 再额外压一层阻尼，让静止时更稳。
        if abs(x) < self.idle_threshold and abs(y) < self.idle_threshold:
            filtered_x *= self.idle_damping
            filtered_y *= self.idle_damping

        return filtered_x, filtered_y
