import torch
import numpy as np
import cv2
import os
import sys
from pathlib import Path
from tqdm import tqdm

# 添加项目根目录到 Python 路径（根据你的实际路径修改）
project_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from Liang.src.isp_utils.CRVD_OpenCV_ISP.OpenCV_ISP import OpenCV_ISP2

def raw_sequence_to_rgb_video(raw_folder, output_video_path, fps=25, bit_depth=12):
    """
    将 RAW 图像序列（TIFF）转换为 RGB 视频
    :param raw_folder: 存放 RAW 图像的文件夹路径
    :param output_video_path: 输出视频文件路径（例如 .mp4）
    :param fps: 视频帧率
    :param bit_depth: RAW 图像位深（默认为 12）
    """
    # 获取所有 RAW 文件并按名称排序
    raw_files = sorted(Path(raw_folder).glob("*.tiff"))  # 如果文件后缀是 .tif 请修改
    if not raw_files:
        print(f"错误：文件夹 {raw_folder} 中没有找到 .tiff 文件")
        return

    # 读取所有帧到 numpy 数组 (T, H, W)
    frames = []
    for f in raw_files:
        img = cv2.imread(str(f), cv2.IMREAD_UNCHANGED).astype(np.float32)
        frames.append(img)
    raw_seq = np.stack(frames, axis=0)  # (T, H, W)
    T, H, W = raw_seq.shape

    # 转换为 torch 张量并添加 batch 维度 (1, T, H, W)
    raw_tensor = torch.from_numpy(raw_seq).unsqueeze(0)

    # 初始化 ISP
    isp = OpenCV_ISP2(show_preview=False)

    # ISP 处理
    print("正在执行 ISP 转换...")
    with torch.no_grad():
        rgb_seq = isp(raw_tensor)[0]  # (T, H, W, 3)，范围 [0,1]

    # 写入视频
    print("正在写入视频...")
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # MP4 编码
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (W, H))

    for i in tqdm(range(T), desc="写入帧"):
        # 转换为 8-bit 用于视频保存
        rgb_8u = (rgb_seq[i] * 255).astype(np.uint8)
        out.write(rgb_8u)

    out.release()
    print(f"视频已保存至：{output_video_path}")

if __name__ == "__main__":
    # ===== 用户配置区域 =====
    # 请根据实际情况修改以下路径和参数
    raw_folder = r"E:/CRVD_dataset/3DNR_vbm3d/scene1/ISO1600"   # 存放 RAW 的文件夹
    output_video = r"C:/Users/HP/Desktop/scene1_ISO1600_denoised.mp4"  # 输出视频路径
    fps = 25  # 帧率
    bit_depth = 12  # RAW 位深
    # =========================

    raw_sequence_to_rgb_video(raw_folder, output_video, fps, bit_depth)