import torch
import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# 添加项目根目录到路径
project_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from Liang.src.data.CRVD.SequenceWise_Load import CRVDDataset
from Liang.src.isp_utils.CRVD_OpenCV_ISP.OpenCV_ISP import OpenCV_ISP2
from Denosie import denoise_temporal_extreme_trail, calculate_ssim_raw

# ===== 路径配置 =====
noisy_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang/Liang/src/data/CRVD/CRVDDataset/indoor_raw_noisy_scene1"
gt_root    = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang/Liang/src/data/CRVD/CRVDDataset/indoor_raw_gt_scene1"
scene_id = 1
iso = 1600  # 可改为其他 ISO

# ===== 加载序列 =====
dataset = CRVDDataset(noisy_root, gt_root, scenes=[scene_id], iso_levels=[iso], sequence_mode=True)
noisy_seq, gt_seq = dataset[0]                     # (7, H, W)
noisy_tensor = torch.from_numpy(noisy_seq).unsqueeze(0)   # (1, 7, H, W)
gt_tensor    = torch.from_numpy(gt_seq).unsqueeze(0)

# ===== 应用极端拖影 3DNR =====
denoised_tensor = denoise_temporal_extreme_trail(
    noisy_tensor,
    alpha_min=0.05,
    alpha_max=0.2,
    scale=50.0
)

# ===== ISP 转为 RGB（仅用于可视化） =====
isp = OpenCV_ISP2(show_preview=False)
denoised_rgb = isp(denoised_tensor)[0]   # (7, H, W, 3)
gt_rgb       = isp(gt_tensor)[0]
noisy_rgb    = isp(noisy_tensor)[0]

# ===== 只计算 RAW 域的 SSIM（不计算 RGB SSIM） =====
raw_ssim = []
for i in range(7):
    s_raw = calculate_ssim_raw(denoised_tensor[0, i], gt_tensor[0, i], data_range=4095.0, channel_wise=False)
    raw_ssim.append(s_raw)
    print(f"Frame {i+1:2d} RAW SSIM = {s_raw:.4f}")

print(f"\n平均 RAW SSIM (7帧) = {np.mean(raw_ssim):.4f}")

# ===== 可视化第二帧（索引为1） =====
fig, axes = plt.subplots(1, 3, figsize=(15,5))
axes[0].imshow(gt_rgb[1])
axes[0].set_title("GT Frame 2")
axes[1].imshow(noisy_rgb[1])
axes[1].set_title("Noisy Frame 2")
axes[2].imshow(denoised_rgb[1])
axes[2].set_title(f"Extreme Trail (RAW SSIM={raw_ssim[1]:.4f})")
for ax in axes:
    ax.axis('off')
plt.tight_layout()
plt.show()