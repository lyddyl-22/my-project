import torch
import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# 如果脚本不在项目根目录运行，可能需要添加根目录到路径
project_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# 导入所需模块
from Liang.src.data.CRVD.SequenceWise_Load import CRVDDataset
from Liang.src.isp_utils.CRVD_OpenCV_ISP.OpenCV_ISP import OpenCV_ISP2
from Denosie import denoise_temporal_simple_average, calculate_ssim

# ===== 配置路径 =====
# 注意：CRVDDataset 期望的根目录是包含 scene1 文件夹的上一级
noisy_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang/Liang/src/data/CRVD/CRVDDataset/indoor_raw_noisy_scene1"
gt_root    = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang/Liang/src/data/CRVD/CRVDDataset/indoor_raw_gt_scene1"
scene_id   = 1
iso        = 6400   # 可修改为其他 ISO 值

# ===== 加载序列 =====
dataset = CRVDDataset(
    noisy_root=noisy_root,
    gt_root=gt_root,
    scenes=[scene_id],
    iso_levels=[iso],
    sequence_mode=True   # 返回 (7, H, W) 的序列
)

if len(dataset) == 0:
    print(f"错误：未找到 scene{scene_id} ISO{iso} 的数据，请检查路径。")
    exit()

noisy_seq, gt_seq = dataset[0]   # (7, H, W)

# 转换为张量并添加 batch 维度
noisy_tensor = torch.from_numpy(noisy_seq).unsqueeze(0)   # (1, 7, H, W)
gt_tensor    = torch.from_numpy(gt_seq).unsqueeze(0)

# ===== 应用简单多帧平均 =====
# denoise_temporal_simple_average 实现：Y_t = (X_t + X_{t-1})/2，第一帧保持不变
denoised_tensor = denoise_temporal_simple_average(noisy_tensor)   # (1, 7, H, W)

# ===== 转换为 RGB 图像（用于 SSIM 计算）=====
isp = OpenCV_ISP2(show_preview=False)
denoised_rgb = isp(denoised_tensor)[0]   # (7, H, W, 3)，取值范围 [0,1]
gt_rgb       = isp(gt_tensor)[0]          # (7, H, W, 3)
noisy_rgb    = isp(noisy_tensor)[0]       # 用于可视化

# 计算 Noisy 的 SSIM
noisy_ssim_vals = []
for i in range(7):
    ssim_val = calculate_ssim(noisy_rgb[i], gt_rgb[i])
    noisy_ssim_vals.append(ssim_val)
print("Noisy SSIM per frame:", [f"{v:.4f}" for v in noisy_ssim_vals])
print(f"Noisy 平均 SSIM = {np.mean(noisy_ssim_vals):.4f}")
# ===== 计算每帧的 SSIM =====
ssim_vals = []
for i in range(7):
    ssim_val = calculate_ssim(denoised_rgb[i], gt_rgb[i])   # 调用 Denosie.py 中的函数
    ssim_vals.append(ssim_val)
    print(f"Frame {i+1:2d}  SSIM = {ssim_val:.4f}")

print(f"\n平均 SSIM (7帧) = {np.mean(ssim_vals):.4f}")

# ===== 可视化第一帧对比 =====
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
axes[0].imshow(gt_rgb[0])
axes[0].set_title("Ground Truth")
axes[0].axis('off')

axes[1].imshow(noisy_rgb[0])
axes[1].set_title("Noisy")
axes[1].axis('off')

axes[2].imshow(denoised_rgb[0])
axes[2].set_title(f"Simple 3DNR (SSIM={ssim_vals[0]:.4f})")
axes[2].axis('off')

plt.tight_layout()
plt.show()