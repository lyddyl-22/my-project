import torch
import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# 添加项目根目录到路径
project_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from Liang.src.data.CRVD.SequenceWise_Load import CRVDDataset
from Liang.src.isp_utils.CRVD_OpenCV_ISP.OpenCV_ISP import OpenCV_ISP2
from Denosie import denoise_temporal_extreme_trail, calculate_ssim

# 路径配置（根据你的实际目录调整）
noisy_root = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang/Liang/src/data/CRVD/CRVDDataset/indoor_raw_noisy_scene1"
gt_root    = r"C:/Users/HP/Desktop/ISP-NoiseReduction-Liang/Liang/src/data/CRVD/CRVDDataset/indoor_raw_gt_scene1"
scene_id = 1
iso = 1600  # 可改为 3200, 6400 等

# 加载序列
dataset = CRVDDataset(noisy_root, gt_root, scenes=[scene_id], iso_levels=[iso], sequence_mode=True)
noisy_seq, gt_seq = dataset[0]
noisy_tensor = torch.from_numpy(noisy_seq).unsqueeze(0)   # (1,7,H,W)
gt_tensor    = torch.from_numpy(gt_seq).unsqueeze(0)

# 应用极端拖影 3DNR（可调整参数）
denoised_tensor = denoise_temporal_extreme_trail(
    noisy_tensor,
    alpha_min=0.05,
    alpha_max=0.2,
    scale=50.0
)

# ISP 转为 RGB
isp = OpenCV_ISP2(show_preview=False)
denoised_rgb = isp(denoised_tensor)[0]   # (7,H,W,3)
gt_rgb       = isp(gt_tensor)[0]
noisy_rgb    = isp(noisy_tensor)[0]

# 计算每帧 SSIM
ssim_vals = []
for i in range(7):
    s = calculate_ssim(denoised_rgb[i], gt_rgb[i])
    ssim_vals.append(s)
    print(f"Frame {i+1:2d}  SSIM = {s:.4f}")
print(f"\n平均 SSIM = {np.mean(ssim_vals):.4f}")

# 可视化第一帧
fig, axes = plt.subplots(1, 3, figsize=(15,5))
axes[0].imshow(gt_rgb[0])
axes[0].set_title("GT")
axes[1].imshow(noisy_rgb[0])
axes[1].set_title("Noisy")
axes[2].imshow(denoised_rgb[0])
axes[2].set_title(f"Extreme Trail (SSIM={ssim_vals[0]:.4f})")
for ax in axes: ax.axis('off')
plt.tight_layout()
plt.show()

# 可额外显示第2帧，观察运动区域拖影
fig2, axes2 = plt.subplots(1, 3, figsize=(15,5))
axes2[0].imshow(gt_rgb[1])
axes2[0].set_title("GT Frame2")
axes2[1].imshow(noisy_rgb[1])
axes2[1].set_title("Noisy Frame2")
axes2[2].imshow(denoised_rgb[1])
axes2[2].set_title(f"Denoised Frame2 (SSIM={ssim_vals[1]:.4f})")
for ax in axes2: ax.axis('off')
plt.tight_layout()
plt.show()