import sys
import os

# 动态获取项目根目录（脚本所在目录的上一级再上一级）
current_file = os.path.abspath(__file__)               # 脚本的完整路径
current_dir = os.path.dirname(current_file)            # Liang/23DNR/
parent_dir = os.path.dirname(current_dir)              # Liang/
project_root = os.path.dirname(parent_dir)             # ISP-NoiseReduction-Liang/

if project_root not in sys.path:
    sys.path.insert(0, project_root)

print(f"项目根目录已添加到 sys.path: {project_root}")
print(f"当前 sys.path: {sys.path}")   # 调试用
try:
    from Liang.src.data.CRVD.SequenceWise_Load import CRVDDataset
    from Liang.src.isp_utils.CRVD_OpenCV_ISP.OpenCV_ISP import OpenCV_ISP2
    from Denosie import (
        denoise_temporal_simple_average,
        denoise_temporal_extreme_trail,
        calculate_psnr,
        create_edge_mask,
        calculate_psnr_masked
    )
except Exception as e:
    print(f"导入错误: {e}")
    exit()
# ----------------------------------------------------------------------
# 新增：边缘掩码与带掩码 PSNR 计算
# ----------------------------------------------------------------------
def create_edge_mask(height, width, edge_ratio=0.15):
    """
    生成边缘掩码，四周各取 edge_ratio 的宽度（基于图像尺寸）。
    返回布尔型 numpy 数组，形状 (height, width)，边缘区域为 True。
    """
    mask = np.zeros((height, width), dtype=bool)
    edge_h = int(height * edge_ratio)
    edge_w = int(width * edge_ratio)
    # 上边缘
    mask[:edge_h, :] = True
    # 下边缘
    mask[-edge_h:, :] = True
    # 左边缘（去除已覆盖的角落）
    mask[edge_h:-edge_h, :edge_w] = True
    # 右边缘
    mask[edge_h:-edge_h, -edge_w:] = True
    return mask

def calculate_psnr_masked(img1, img2, mask=None, max_val=4095.0):
    """
    带掩码的 PSNR 计算，只考虑 mask 为 True 的像素。
    如果 mask 为 None，则计算全图 PSNR（回退到原函数）。
    """
    if torch.is_tensor(img1):
        img1 = img1.detach().cpu().numpy()
        img2 = img2.detach().cpu().numpy()
    if mask is not None:
        if torch.is_tensor(mask):
            mask = mask.detach().cpu().numpy()
        mask = mask.astype(bool)
        pixels1 = img1[mask]
        pixels2 = img2[mask]
    else:
        pixels1 = img1.ravel()
        pixels2 = img2.ravel()
    mse = np.mean((pixels1.astype(np.float64) - pixels2.astype(np.float64)) ** 2)
    if mse == 0:
        return float("inf")
    return 10 * np.log10(max_val ** 2 / mse)