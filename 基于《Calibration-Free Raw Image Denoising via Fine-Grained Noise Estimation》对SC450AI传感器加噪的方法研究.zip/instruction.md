# SC450AI RAW Frame Extractor

## 概述
从SC450AI传感器输出的RAW流文件中提取多帧图像，支持High/Low 12bit格式，并可选转换到物理亮度空间。

## 依赖
- Python 3.6+
- numpy
- opencv-python（仅当输出PNG时需要）

## 参数
| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| raw_file | str | 必填 | RAW文件路径 |
| height | int | 必填 | 单帧高度（像素） |
| width | int | 必填 | 单帧宽度（像素） |
| --byteorder | str | little | 字节序，可选little/big |
| --black_level | int | 258 | 物理空间黑电平 |
| --high12bit | flag | 无 | 输入为High 12bit格式（需右移4位） |
| --output_dir | str | . | 输出目录 |
| --output_format | str | npy | 输出格式：npy/raw/png |

## 示例
```bash
# 提取High 12bit文件，保存为npy
python extract_frames.py raw_stream.raw 1520 2688 --high12bit

# 提取Low 12bit文件，输出原始二进制
python extract_frames.py light.raw 1520 804 --output_format raw