#!/usr/bin/env python3
"""
SC450AI RAW文件帧分解工具
支持 High 12bit (左移4位存储) 和 Low 12bit 格式
"""

import numpy as np
import os
import argparse
from pathlib import Path

def extract_frames(raw_file, height, width, byteorder='little', black_level=258,
                   high12bit=False, output_dir='.', output_format='npy'):
    """
    从RAW文件中提取所有帧

    Parameters:
    -----------
    raw_file : str
        RAW文件路径
    height : int
        单帧高度（像素）
    width : int
        单帧宽度（像素）
    byteorder : str, 'little' or 'big'
        字节序，默认小端
    black_level : int
        黑电平值，物理空间下默认258
    high12bit : bool
        是否为High 12bit格式（需要右移4位）
    output_dir : str
        输出目录
    output_format : str
        输出格式：'npy', 'raw', 'png'（需要安装opencv-python或imageio）
    """

    # 确定数据类型
    dtype = '<u2' if byteorder == 'little' else '>u2'

    # 读取整个文件
    raw_data = np.fromfile(raw_file, dtype=dtype)
    total_pixels = raw_data.size
    frame_pixels = height * width

    # 计算帧数
    if total_pixels % frame_pixels != 0:
        print(f"警告：总像素数 {total_pixels} 不是单帧像素数 {frame_pixels} 的整数倍")
        # 截断多余像素
        num_frames = total_pixels // frame_pixels
        raw_data = raw_data[:num_frames * frame_pixels]
    else:
        num_frames = total_pixels // frame_pixels

    print(f"文件总像素: {total_pixels}, 单帧像素: {frame_pixels}, 帧数: {num_frames}")

    # 重塑为 (帧数, 高度, 宽度)
    frames = raw_data.reshape(num_frames, height, width)

    # 转换到物理亮度空间（如果需要）
    if high12bit:
        # High 12bit: 右移4位，再减黑电平
        physical = (frames >> 4).astype(np.float32) - black_level
    else:
        # Low 12bit: 直接减黑电平
        physical = frames.astype(np.float32) - black_level

    # 裁剪负值
    physical = np.clip(physical, 0, 4095)

    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 保存每一帧
    for i in range(num_frames):
        if output_format == 'npy':
            out_path = Path(output_dir) / f"frame_{i:04d}.npy"
            np.save(out_path, physical[i])
        elif output_format == 'raw':
            # 保存为原始二进制（uint16）
            out_path = Path(output_dir) / f"frame_{i:04d}.raw"
            physical[i].astype(np.uint16).tofile(out_path)
        elif output_format == 'png':
            # 需要安装 opencv-python 或 imageio
            try:
                import cv2
                # 归一化到0-255以便保存为灰度图
                img_8bit = (physical[i] / 16).astype(np.uint8)  # 4095/16≈255
                out_path = Path(output_dir) / f"frame_{i:04d}.png"
                cv2.imwrite(str(out_path), img_8bit)
            except ImportError:
                print("未安装opencv-python，请使用 pip install opencv-python")
                return
        else:
            raise ValueError(f"不支持的输出格式: {output_format}")

        print(f"已保存: {out_path}")

    print(f"共处理 {num_frames} 帧，输出至 {output_dir}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SC450AI RAW文件帧分解工具")
    parser.add_argument("raw_file", help="RAW文件路径")
    parser.add_argument("height", type=int, help="单帧高度")
    parser.add_argument("width", type=int, help="单帧宽度")
    parser.add_argument("--byteorder", default="little", choices=["little", "big"],
                        help="字节序，默认小端")
    parser.add_argument("--black_level", type=int, default=258,
                        help="黑电平（物理亮度空间），默认258")
    parser.add_argument("--high12bit", action="store_true",
                        help="标记为High 12bit格式（需要右移4位）")
    parser.add_argument("--output_dir", default=".", help="输出目录")
    parser.add_argument("--output_format", default="npy",
                        choices=["npy", "raw", "png"], help="输出格式")
    args = parser.parse_args()

    extract_frames(
        raw_file=args.raw_file,
        height=args.height,
        width=args.width,
        byteorder=args.byteorder,
        black_level=args.black_level,
        high12bit=args.high12bit,
        output_dir=args.output_dir,
        output_format=args.output_format
    )